# TEAM_ID × PS_ID: SyncPulse PHP — Connected Community Care

SyncPulse is a community-healthcare portal for ASHA workers, supervisors, and
patients. It gives each group a separate, role-protected workspace for managing
patients, home visits, and health alerts without spreadsheets or paper registers.

> **Submission metadata:** replace `TEAM_ID` and `PS_ID` in this heading and in
> the archive/folder name with the official team and problem-statement IDs before
> uploading.

## What it does

- **Super admin:** registers ASHA workers, activates or deactivates accounts, and
  views every patient, visit, and alert across all villages.
- **ASHA worker:** adds and edits patients in their own village, schedules visits,
  completes or cancels visits, raises alerts, resolves alerts, searches patients,
  and reviews visit metrics and offline health guides.
- **Patient:** self-registers, signs in, edits their health profile, books a home
  visit, cancels an upcoming visit, and sends a help request.
- **Automatic assignment:** a self-registering patient is assigned to an active
  worker in the same village when one is available; otherwise the patient remains
  unassigned for an admin or worker to pick up.
- **Installable, offline-aware UI:** a web manifest and service worker cache the
  application shell and read-only pages after the first successful visit.

All patient records and accounts in the seed data are fictional.

## How to run

### Requirements

- PHP 8.1 or newer with `pdo_mysql`, `mbstring`, and `openssl`
- MySQL 5.7+ or 8.0+ (tested with MySQL 8.4)
- A web server; PHP's built-in server is sufficient for local demos
- Internet access on first load for Google Fonts and the Lucide icon CDN. The
  application still works without them; fonts and icons fall back gracefully.

### 1. Configure the database

Copy the environment template and edit it with local values:

```powershell
Copy-Item FULL_CODE/.env.example FULL_CODE/.env
```

```text
SYNCPULSE_DB_HOST=127.0.0.1
SYNCPULSE_DB_PORT=3306
SYNCPULSE_DB_NAME=syncpulse
SYNCPULSE_DB_USER=root
SYNCPULSE_DB_PASS=change-me
```

`FULL_CODE/.env` is loaded only when the same names are not already present in
the real server environment. Never commit the real `.env`; it is ignored.

### 2. Create the schema and demo data

Run from the repository root:

```bash
php FULL_CODE/database/setup.php
```

The script creates the database, applies `FULL_CODE/database/schema.sql`, and
seeds demo accounts. It is idempotent: existing tables and rows are preserved, so
re-running it does not wipe local data.

### 3. Start the app

```bash
php -S 127.0.0.1:8000 -t FULL_CODE
```

Open <http://127.0.0.1:8000/>. With Laragon/Apache, serve the repository root and
open `FULL_CODE/index.php` through the configured virtual host instead.

### Demo accounts

| Role | Login | Password |
| --- | --- | --- |
| Super admin | `admin@syncpulse.local` | `Admin@123` |
| ASHA worker | `DEMO-ASHA-001` | `Worker@123` |
| ASHA worker | `DEMO-ASHA-002` | `Worker@123` |
| Patient | `lakshmi.devi@example.com` | `Patient@123` |

Replace or remove these accounts and passwords before any real deployment.

## How to run the tests

```bash
php FULL_CODE/tests/run_tests.php
```

The plain-PHP runner checks name initials and date formatting edge cases, seeded
article data, environment/database configuration, the `.env` loader, and that
patient queries never select `password_hash`. It needs no database connection and
exits non-zero on failure.

Lint every PHP file with:

```powershell
Get-ChildItem FULL_CODE -Recurse -Filter *.php | ForEach-Object { php -l $_.FullName }
```

## Architecture

```text
Browser
  |
  +-- index.php ---------------------- public landing page
  +-- admin/ ------------------------- super-admin login + dashboard
  +-- worker/ ------------------------ ASHA worker login + workspace
  +-- patient/ ----------------------- patient login, registration, portal
  |
  +-- includes/
  |     +-- config.php --------------- environment loading + DB settings
  |     +-- db.php ------------------- PDO connection factories + timeout
  |     +-- auth.php ----------------- sessions, roles, CSRF, flash messages
  |     +-- data.php ----------------- queries, validation helpers, content
  |
  +-- database/
  |     +-- schema.sql --------------- InnoDB/utf8mb4 tables + foreign keys
  |     +-- setup.php ---------------- idempotent database/seed setup
  |
  +-- assets/ + sw.js ---------------- CSS, JS, icons, manifest, service worker
  +-- tests/run_tests.php ------------ dependency-free core-logic tests
```

The portals are server-rendered PHP pages. Each portal controller handles its own
POST actions, checks the session role and CSRF token, validates input, and then
calls shared helpers in `includes/`. SQL lives in `includes/data.php` and uses
prepared statements. The schema is versioned in `database/schema.sql`; there is
no hand-created-only database state.

There is no Composer, npm, or other server-side package manager in this project,
so there is no lockfile to commit. Runtime third-party assets are loaded directly
from pinned/CDN URLs:

- **Lucide 1.64.0** (ISC licence) via unpkg for icons
- **DM Sans** via Google Fonts (SIL Open Font License)

## Security

- Passwords are hashed with `password_hash()` and checked with `password_verify()`.
- All database writes use PDO prepared statements; patient queries select explicit
  columns so password hashes never reach the browser.
- Every state-changing form is CSRF-protected, with a `419` response on failure.
- Role checks are enforced on the server; hidden navigation is not access control.
- Sessions use `HttpOnly`, `SameSite=Lax`, `Secure` when HTTPS is active, strict
  mode, and a root-scoped cookie.
- Patient/visit/alert ownership is checked before updates, and worker actions are
  limited to patients assigned to that worker.
- User-supplied values are escaped before HTML output, and date/time/enum inputs
  are validated against allowed formats and values.
- PDO calls use a connection timeout. Setup errors log details for developers and
  show a generic message in the browser.
- `.env`, logs, dumps, dependency folders, build output, and archives are ignored.

## Verification performed

Local checks on the submission copy:

- PHP lint: 33 files, 0 failures.
- Core tests: 18 checks, 0 failures.
- Fresh database import and idempotent re-run: passed.
- HTTP smoke tests: 25 checks covering landing/help pages, login for all three
  roles, admin and worker views, patient registration, logout, and unauthenticated
  redirects.
- Write-flow tests: 14 checks covering patient creation, visit scheduling and
  completion, alert creation and resolution, worker ownership checks, invalid
  category rejection, worker creation/deactivation, patient help/booking/cancel,
  cross-patient cancel rejection, and CSRF `419` rejection.

## AI usage

- **Runtime:** SyncPulse does not call any LLM, AI API, agent, or model. There is
  no AI-generated content at runtime.
- **Development:** the opencode CLI coding assistant (big-pickle) was used to
  review, harden, test, and document this submission. Add any other AI coding
  assistants used by the team before uploading.

## Pre-built and third-party code

- The SyncPulse application was written for this hackathon project and existed
  before the final review/hardening pass. The team must confirm it was not reused
  from another hackathon or past project, as required by the fair-play rules.
- No starter kit or copied application template was identified in the codebase.
- Third-party runtime assets are limited to Lucide (ISC) and DM Sans (OFL), as
  listed above. No third-party PHP packages are bundled.
- All demo records are synthetic.

## Limitations and next steps

- The `submission/` folder is intentionally empty until the official problem
  statement's required output file name and format are confirmed. Do not invent
  an output file.
- The real team ID and problem-statement ID have not been supplied; the workspace
  and archive currently use `TEAM_ID_PS_ID` as placeholders.
- Offline mode is read-only and limited to previously cached pages; writes require
  connectivity.
- There are no email/SMS notifications, password-reset flow, audit-trail UI, or
  multi-factor authentication yet.
- Production deployment still needs TLS termination, rate limiting, backups,
  database migrations, monitoring, and secret management.
- The committed tests cover core helpers, not every HTTP route; the broader route
  and write-flow checks above were run manually against a local test database.
