<?php
require_once __DIR__ . '/includes/auth.php';

$worker = current_worker();
$patientId = current_patient_id();
$admin = current_admin();
$workerHref = $worker ? 'worker/index.php' : 'worker/login.php';
$patientHref = $patientId ? 'patient/index.php' : 'patient/login.php';
$adminHref = $admin ? 'admin/index.php' : 'admin/login.php';
$workerName = $worker['name'] ?? 'ASHA Worker';
$adminName = $admin['name'] ?? 'Super Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SyncPulse - Connected Community Care</title>
    <meta name="description" content="SyncPulse — Connected Community Care. Offline-first healthcare demonstration.">
    <link rel="manifest" href="assets/manifest.webmanifest">
    <link rel="icon" href="assets/icon.svg" type="image/svg+xml">
    <link rel="icon" href="assets/favicon.ico" sizes="any">
    <link rel="apple-touch-icon" href="assets/icon-192.png">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="landing-body">
    <div class="landing">
        <div class="welcome">
            <div class="welcome-art">
                <i data-lucide="activity"></i>
                <span class="welcome-product-name">Sync Pulse</span>
                <span class="eyebrow">CARE THAT GOES THE DISTANCE</span>
                <h1>
                    Connected Care,
                    <br />
                    Even Offline.
                </h1>
                <p>
                    Healthier communities start with a connection. Your village.
                    Your people. Your SyncPulse.
                </p>
                <div class="welcome-pills">
                    <span>
                        <i data-lucide="wifi-off"></i> Offline ready
                    </span>
                    <span>
                        <i data-lucide="database"></i> MySQL powered
                    </span>
                </div>
            </div>
            <div class="welcome-options">
                <span class="eyebrow">WELCOME TO SYNC PULSE</span>
                <h2>A little closer to better care.</h2>
                <p>Choose your space to get started.</p>

                <a class="portal-option" href="<?php echo htmlspecialchars($adminHref); ?>">
                    <i data-lucide="shield-check"></i>
                    <div>
                        <strong><?php echo $admin ? 'Continue as ' . htmlspecialchars($adminName) : 'Super Admin Login'; ?></strong>
                        <small>Register and manage ASHA workers</small>
                    </div>
                    <i data-lucide="arrow-right"></i>
                </a>

                <a class="portal-option" href="<?php echo htmlspecialchars($workerHref); ?>">
                    <i data-lucide="stethoscope"></i>
                    <div>
                        <strong><?php echo $worker ? 'Continue as ' . htmlspecialchars($workerName) : 'ASHA Worker Login'; ?></strong>
                        <small>Your community care workspace</small>
                    </div>
                    <i data-lucide="arrow-right"></i>
                </a>

                <a class="portal-option" href="<?php echo htmlspecialchars($patientHref); ?>">
                    <i data-lucide="heart"></i>
                    <div>
                        <strong><?php echo $patientId ? 'Continue to Patient Portal' : 'Patient Portal Login'; ?></strong>
                        <small>Visits, support, and your health</small>
                    </div>
                    <i data-lucide="arrow-right"></i>
                </a>

                <a class="text-button" href="patient/register.php">
                    New patient? Create your account <i data-lucide="arrow-right"></i>
                </a>

                <small class="demo-note">
                    Demo accounts: admin@syncpulse.local / Admin@123 · DEMO-ASHA-001 / Worker@123<br>
                    Worker accounts are created by the super admin. Patients can self-register.
                </small>

                <a class="text-button" href="README.php">
                    README <i data-lucide="arrow-right"></i>
                </a>

            </div>
        </div>
    </div>

    <script src="https://unpkg.com/lucide@1.64.0/dist/umd/lucide.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
