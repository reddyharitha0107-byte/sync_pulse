<?php
require_once __DIR__ . '/../../includes/data.php';
$data = getSeedData();
$articles = getArticles();
$worker = current_worker();
$workerFirstName = explode(' ', $worker['name'] ?? 'ASHA Worker')[0];

$activeAlerts = array_filter($data['alerts'], function($a) { return !$a['resolved']; });
$completed = count(array_filter($data['visits'], function($v) { return $v['status'] === 'Completed'; }));
$pendingVisits = array_filter($data['visits'], function($v) { return $v['status'] !== 'Completed'; });
$today = date('Y-m-d');
$todayVisits = array_filter($data['visits'], function($v) use ($today) { return $v['date'] === $today; });
$visitFilter = $_GET['filter'] ?? 'Today';
?>
<div class="page-heading">
    <div>
        <div class="eyebrow">YOUR COMMUNITY, IN GOOD HANDS</div>
        <h1>
            Good morning, <?php echo htmlspecialchars($workerFirstName); ?>
            <i data-lucide="sun" class="sun-icon"></i>
        </h1>
        <p>Here’s what’s happening in your community today.</p>
    </div>
    <div class="heading-actions">
        <span class="date-label">
            <i data-lucide="calendar-days"></i>
            <?php echo date('D, d M Y'); ?>
        </span>
    </div>
</div>

<div class="care-banner">
    <div class="care-banner-icon">
        <i data-lucide="leaf"></i>
    </div>
    <div>
        <strong>A connected day of care starts here.</strong>
        <p><?php echo count(array_filter($todayVisits, function($v) { return $v['status'] !== 'Completed'; })); ?> visits on your schedule. Every visit makes a difference.</p>
    </div>
    <button onclick="window.location.href='?view=Alerts'">
        View today’s plan <i data-lucide="arrow-right"></i>
    </button>
    <div class="banner-illustration">
        <i data-lucide="heart-pulse"></i>
        <span></span>
        <i></i>
    </div>
</div>

<div class="stats-grid">
    <?php
    $stats = [
        ['label' => 'Total patients', 'value' => count($data['patients']), 'icon' => 'users', 'change' => 'Across 2 villages', 'color' => 'teal', 'target' => 'Patients'],
        ['label' => 'Visits completed', 'value' => $completed, 'icon' => 'check-check', 'change' => 'Care delivered this month', 'color' => 'green', 'target' => 'Metrics'],
        ['label' => 'Pending visits', 'value' => count($pendingVisits), 'icon' => 'calendar-days', 'change' => count(array_filter($data['visits'], function($v) { return $v['status'] === 'Overdue'; })) . ' overdue · needs attention', 'color' => 'orange', 'target' => 'Alerts'],
        ['label' => 'Active emergencies', 'value' => count($activeAlerts), 'icon' => 'activity', 'change' => 'Review and follow up', 'color' => 'rose', 'target' => 'Emergency'],
    ];
    foreach ($stats as $s) {
    ?>
    <button class="stat-card" onclick="window.location.href='?view=<?php echo $s['target']; ?>'">
        <div class="stat-label">
            <?php echo $s['label']; ?>
            <span class="stat-icon <?php echo $s['color']; ?>">
                <i data-lucide="<?php echo $s['icon']; ?>"></i>
            </span>
        </div>
        <strong><?php echo str_pad($s['value'], 2, '0', STR_PAD_LEFT); ?></strong>
        <span class="stat-note <?php echo $s['color']; ?>">
            <?php if ($s['label'] === 'Visits completed'): ?><i data-lucide="arrow-up-right"></i><?php endif; ?>
            <?php echo $s['change']; ?>
        </span>
    </button>
    <?php } ?>
</div>

<div class="dashboard-columns">
    <section class="panel schedule-panel">
        <div class="panel-header">
            <div>
                <h2>Today’s visits <span class="count"><?php echo count($todayVisits); ?></span></h2>
                <p>A little care, right at their doorstep.</p>
            </div>
            <button class="text-button" onclick="window.location.href='?view=Alerts'">
                View all <i data-lucide="arrow-right"></i>
            </button>
        </div>
        <div class="tabs">
            <?php foreach (['Today', 'Upcoming', 'Completed'] as $t): ?>
            <button class="<?php echo ($visitFilter === $t) ? 'selected' : ''; ?>" onclick="window.location.href='?view=Overview&filter=<?php echo $t; ?>'">
                <?php echo $t; ?>
                <?php if ($t === 'Today'): ?><span><?php echo count($todayVisits); ?></span><?php endif; ?>
            </button>
            <?php endforeach; ?>
            <span class="tabs-end">
                <i data-lucide="calendar-days"></i> <?php echo dateLabel($today); ?>
            </span>
        </div>
        <div class="visit-list">
            <?php
            if ($visitFilter === 'Today') {
                $visitsToShow = array_slice($todayVisits, 0, 4);
            } elseif ($visitFilter === 'Completed') {
                $visitsToShow = array_slice(array_filter($data['visits'], function($v) { return $v['status'] === 'Completed'; }), 0, 4);
            } else {
                $visitsToShow = array_slice(array_filter($data['visits'], function($v) { return $v['status'] === 'Upcoming'; }), 0, 4);
            }
            foreach ($visitsToShow as $i => $v) {
                $p = null;
                foreach ($data['patients'] as $pat) {
                    if ($pat['id'] === $v['patientId']) { $p = $pat; break; }
                }
                if (!$p) continue;
            ?>
            <div class="visit-row">
                <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo initials($p['name']); ?></div>
                <div class="visit-info">
                    <button class="text-button patient-name" onclick="openProfile('<?php echo $p['id']; ?>')">
                        <?php echo htmlspecialchars($p['name']); ?>
                    </button>
                    <span><?php echo htmlspecialchars($v['type']); ?></span>
                    <small>
                        <i data-lucide="map-pin"></i>
                        <?php echo htmlspecialchars($p['village']); ?> <i></i> <?php echo ($v['date'] === $today) ? 'Today' : dateLabel($v['date']); ?>
                    </small>
                </div>
                <div class="visit-end">
                    <span class="time">
                        <i data-lucide="clock-3"></i>
                        <?php echo htmlspecialchars($v['time']); ?>
                    </span>
                    <span class="badge <?php echo ($v['status'] === 'Completed') ? 'green' : (($v['status'] === 'Overdue') ? 'red' : 'amber'); ?>">
                        <?php echo htmlspecialchars($v['status']); ?>
                    </span>
                </div>
                <button class="icon-button row-arrow" aria-label="View visit" onclick="openProfile('<?php echo $p['id']; ?>')">
                    <i data-lucide="chevron-right"></i>
                </button>
            </div>
            <?php } ?>
        </div>
        <div class="panel-bottom">
            <span>
                <i data-lucide="map-pin"></i>
                Rampur & Chandpur villages
            </span>
            <button class="text-button" onclick="openModal('schedule')">
                Schedule a visit <i data-lucide="plus"></i>
            </button>
        </div>
    </section>
    
    <section class="panel emergency-panel">
        <div class="panel-header">
            <div>
                <h2><span class="live-dot"></span> Needs attention</h2>
                <p>A timely response makes a difference.</p>
            </div>
            <span class="count red-count"><?php echo count($activeAlerts); ?></span>
        </div>
        <?php foreach (array_slice($activeAlerts, 0, 1) as $a): 
            $p = null;
            foreach ($data['patients'] as $pat) {
                if ($pat['id'] === $a['patientId']) { $p = $pat; break; }
            }
            if (!$p) continue;
        ?>
        <div class="emergency-item <?php echo ($a['urgency'] === 'High') ? 'critical' : ''; ?>">
            <div class="emergency-item-top">
                <span class="badge <?php echo ($a['urgency'] === 'High') ? 'red' : 'amber'; ?>">
                    <?php echo ($a['urgency'] === 'High') ? 'High priority' : htmlspecialchars($a['urgency']); ?>
                </span>
                <span class="muted">Demo alert</span>
            </div>
            <h3><?php echo htmlspecialchars($p['name']); ?></h3>
            <p><?php echo htmlspecialchars($a['condition']); ?></p>
            <small>
                <i data-lucide="map-pin"></i>
                <?php echo htmlspecialchars($p['village']); ?> village
            </small>
            <button class="text-button" onclick="openRespond(<?php echo (int) $a['id']; ?>, <?php echo htmlspecialchars(json_encode($p['name']), ENT_QUOTES); ?>, <?php echo htmlspecialchars(json_encode($a['condition']), ENT_QUOTES); ?>)">
                Review alert <i data-lucide="arrow-right"></i>
            </button>
        </div>
        <?php endforeach; ?>
        <button class="full-link" onclick="window.location.href='?view=Emergency'">
            View all alerts <i data-lucide="arrow-right"></i>
        </button>
    </section>
</div>
