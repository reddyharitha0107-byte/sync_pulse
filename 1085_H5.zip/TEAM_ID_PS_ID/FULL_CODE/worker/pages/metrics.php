<?php
require_once __DIR__ . '/../../includes/data.php';
$data = getSeedData();
$completed = count(array_filter($data['visits'], function($v) { return $v['status'] === 'Completed'; }));
$total = count($data['visits']);
$percentage = $total > 0 ? round(($completed / $total) * 100) : 0;
?>
<div class="page-heading">
    <div>
        <div class="eyebrow">SYNCPULSE WORKSPACE</div>
        <h1>Your impact, at a glance</h1>
        <p>A clearer picture of the care you deliver.</p>
    </div>
</div>

<div class="stats-grid">
    <?php
    $stats = [
        ['label' => 'Total patients', 'value' => count($data['patients']), 'icon' => 'users', 'change' => 'Across 2 villages', 'color' => 'teal'],
        ['label' => 'Visits completed', 'value' => $completed, 'icon' => 'check-check', 'change' => 'Care delivered this month', 'color' => 'green'],
        ['label' => 'Pending visits', 'value' => count(array_filter($data['visits'], function($v) { return $v['status'] !== 'Completed'; })), 'icon' => 'calendar-days', 'change' => count(array_filter($data['visits'], function($v) { return $v['status'] === 'Overdue'; })) . ' overdue · needs attention', 'color' => 'orange'],
        ['label' => 'Active emergencies', 'value' => count(array_filter($data['alerts'], function($a) { return !$a['resolved']; })), 'icon' => 'activity', 'change' => 'Review and follow up', 'color' => 'rose'],
    ];
    foreach ($stats as $s) {
    ?>
    <div class="stat-card">
        <div class="stat-label">
            <?php echo $s['label']; ?>
            <span class="stat-icon <?php echo $s['color']; ?>">
                <i data-lucide="<?php echo $s['icon']; ?>"></i>
            </span>
        </div>
        <strong><?php echo str_pad($s['value'], 2, '0', STR_PAD_LEFT); ?></strong>
        <span class="stat-note <?php echo $s['color']; ?>">
            <?php if ($s['label'] === 'Visits completed'): ?><i data-lucide="arrow-up-right"></i><?php endif; ?>
            <?php echo $s['change']; ?>
        </span>
    </div>
    <?php } ?>
</div>

<div class="dashboard-columns">
    <section class="panel">
        <div class="panel-header">
            <div>
                <h2>Your week of care</h2>
                <p>Live visit counts from your database</p>
            </div>
        </div>
        <div class="chart-legend">
            <span><i class="legend-light"></i> Scheduled</span>
            <span><i></i> Completed</span>
        </div>
        <div class="chart">
            <div class="chart-y">
                <span>8</span><span>6</span><span>4</span><span>2</span><span>0</span>
            </div>
            <div class="chart-bars">
                <?php
                for ($i = 6; $i >= 0; $i--) {
                    $d = new DateTime();
                    $d->modify('-' . $i . ' days');
                    $dateStr = $d->format('Y-m-d');
                    $scheduled = count(array_filter($data['visits'], function($v) use ($dateStr) { return $v['date'] === $dateStr; }));
                    $done = count(array_filter($data['visits'], function($v) use ($dateStr) { return $v['date'] === $dateStr && $v['status'] === 'Completed'; }));
                ?>
                <div class="chart-column">
                    <div class="bar-pair">
                        <div style="height: <?php echo max(2, $scheduled * 15); ?>px;" class="bar light"></div>
                        <div style="height: <?php echo max(2, $done * 15); ?>px;" class="bar dark"></div>
                    </div>
                    <span><?php echo $d->format('D'); ?></span>
                </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <section class="panel impact-panel">
        <h2>Every visit counts</h2>
        <div class="progress-ring" style="background: conic-gradient(#0b8c7c <?php echo $percentage; ?>%, #e8f1ee 0);">
            <div>
                <strong><?php echo $percentage; ?>%</strong>
                <span>Visits completed</span>
            </div>
        </div>
        <p><?php echo $completed; ?> of <?php echo $total; ?> visits completed</p>
    </section>
</div>
