<?php
require_once __DIR__ . '/../../includes/data.php';
$data = getSeedData();
$articles = getArticles();
$view = $_GET['view'] ?? 'Overview';
$filter = $_GET['filter'] ?? 'All patients';
$query = $_GET['q'] ?? '';
?>
<?php if ($view === 'Patients'): ?>
<div class="page-heading">
    <div>
        <div class="eyebrow">SYNCPULSE WORKSPACE</div>
        <h1>Your community of care</h1>
        <p>A little knowledge about each person. A lot of better care.</p>
    </div>
    <div class="heading-actions">
        <button class="primary-button" onclick="openModal('add')">
            <i data-lucide="plus"></i>
            Add patient
        </button>
    </div>
</div>
<section class="panel">
    <div class="table-toolbar">
        <label class="search-input">
            <i data-lucide="search"></i>
            <input value="<?php echo htmlspecialchars($query); ?>" onkeyup="searchPatients(this.value)" aria-label="Search patients" placeholder="Search by name, village, or care need…">
        </label>
        <select aria-label="Filter patients" onchange="filterPatients(this.value)">
            <?php foreach (['All patients', 'Maternal care', 'Chronic care', 'Child health', 'General care'] as $t): ?>
            <option <?php echo ($filter === $t) ? 'selected' : ''; ?>><?php echo $t; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Village</th>
                    <th>Care focus</th>
                    <th>Last visit</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $filtered = array_filter($data['patients'], function($p) use ($filter) {
                    return $filter === 'All patients' || $p['category'] === $filter;
                });
                $i = 0;
                foreach ($filtered as $p) {
                    $lastVisit = 'No visits yet';
                    foreach ($data['visits'] as $v) {
                        if ($v['patientId'] === $p['id'] && $v['status'] === 'Completed') {
                            $lastVisit = dateLabel($v['date']);
                            break;
                        }
                    }
                ?>
                <tr data-search="<?php echo htmlspecialchars(strtolower($p['name'] . ' ' . $p['village'] . ' ' . $p['category'])); ?>">
                    <td>
                        <div class="patient-cell">
                            <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo initials($p['name']); ?></div>
                            <div>
                                <strong><?php echo htmlspecialchars($p['name']); ?></strong>
                                <small><?php echo (int) $p['age']; ?> years · <?php echo htmlspecialchars($p['gender']); ?></small>
                            </div>
                        </div>
                    </td>
                    <td><?php echo htmlspecialchars($p['village']); ?></td>
                    <td>
                        <span class="badge <?php echo ($p['category'] === 'Maternal care') ? 'teal' : (($p['category'] === 'Child health') ? 'amber' : 'neutral'); ?>">
                            <?php echo htmlspecialchars($p['category']); ?>
                        </span>
                    </td>
                    <td><?php echo htmlspecialchars($lastVisit); ?></td>
                    <td>
                        <button class="text-button" onclick="openProfile('<?php echo $p['id']; ?>')">
                            View profile
                            <i data-lucide="chevron-right"></i>
                        </button>
                    </td>
                </tr>
                <?php $i++; } ?>
            </tbody>
        </table>
    </div>
    <div class="empty" id="patientEmpty" style="display:none;">
        <i data-lucide="search-x"></i>
        <h3>No patients found</h3>
        <p>Try a different name, village, or care focus.</p>
    </div>
    <div class="panel-bottom">
        <?php echo count($data['patients']); ?> patients in your community <span>MySQL database</span>
    </div>
</section>
<?php endif; ?>
