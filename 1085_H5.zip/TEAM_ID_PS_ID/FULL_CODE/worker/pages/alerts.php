<?php
require_once __DIR__ . '/../../includes/data.php';
$data = getSeedData();
$articles = getArticles();
$view = $_GET['view'] ?? 'Alerts';
$visitFilter = $_GET['filter'] ?? 'Today';
$today = date('Y-m-d');
$todayVisits = array_filter($data['visits'], function($v) use ($today) { return $v['date'] === $today; });
$activeAlerts = array_filter($data['alerts'], function($a) { return !$a['resolved']; });
$resolved = array_filter($data['alerts'], function($a) { return $a['resolved']; });
?>
<?php if ($view === 'Alerts'): ?>
<div class="section-actions">
    <div class="tabs standalone">
        <?php foreach (['Today', 'Upcoming', 'Overdue', 'Completed'] as $t): ?>
        <button class="<?php echo ($visitFilter === $t) ? 'selected' : ''; ?>" onclick="window.location.href='?view=Alerts&filter=<?php echo $t; ?>'">
            <?php echo $t; ?>
        </button>
        <?php endforeach; ?>
    </div>
    <button class="primary-button" onclick="openModal('schedule')">
        <i data-lucide="plus"></i>
        Schedule visit
    </button>
</div>
<section class="panel">
    <div class="visit-list">
        <?php
        if ($visitFilter === 'Today') {
            $visitsToShow = $todayVisits;
        } else {
            $visitsToShow = array_filter($data['visits'], function($v) use ($visitFilter) { return $v['status'] === $visitFilter; });
        }
        if (empty($visitsToShow)) {
            echo '<div class="empty"><i data-lucide="check-check"></i><h3>All clear here</h3><p>No visits match this selection.</p></div>';
        } else {
            $i = 0;
            foreach ($visitsToShow as $v) {
                $p = null;
                foreach ($data['patients'] as $pat) {
                    if ($pat['id'] === $v['patientId']) { $p = $pat; break; }
                }
                if (!$p) continue;
        ?>
        <div class="visit-row">
            <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo initials($p['name']); ?></div>
            <div class="visit-info">
                <button class="text-button patient-name" onclick="openProfile('<?php echo $p['id']; ?>')">
                    <?php echo htmlspecialchars($p['name']); ?>
                </button>
                <span><?php echo htmlspecialchars($v['type']); ?></span>
                <small>
                    <i data-lucide="map-pin"></i>
                    <?php echo htmlspecialchars($p['village']); ?> <i></i> <?php echo ($v['date'] === $today) ? 'Today' : dateLabel($v['date']); ?>
                </small>
            </div>
            <div class="visit-end">
                <span class="time">
                    <i data-lucide="clock-3"></i>
                    <?php echo htmlspecialchars($v['time']); ?>
                </span>
                <span class="badge <?php echo ($v['status'] === 'Completed') ? 'green' : (($v['status'] === 'Overdue' || $v['status'] === 'Cancelled') ? 'red' : 'amber'); ?>">
                    <?php echo htmlspecialchars($v['status']); ?>
                </span>
                <?php if ($v['status'] !== 'Completed' && $v['status'] !== 'Cancelled'): ?>
                <form method="post" class="inline-form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="complete_visit">
                    <input type="hidden" name="visit_id" value="<?php echo (int) $v['id']; ?>">
                    <button class="status-action" type="submit" title="Mark completed"><i data-lucide="check"></i></button>
                </form>
                <form method="post" class="inline-form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="cancel_visit">
                    <input type="hidden" name="visit_id" value="<?php echo (int) $v['id']; ?>">
                    <button class="status-action danger" type="submit" title="Cancel visit"><i data-lucide="x"></i></button>
                </form>
                <?php endif; ?>
            </div>
            <button class="icon-button row-arrow" onclick="openProfile('<?php echo $p['id']; ?>')">
                <i data-lucide="chevron-right"></i>
            </button>
        </div>
        <?php $i++; }
        } ?>
    </div>
</section>
<?php endif; ?>

<?php if ($view === 'Emergency'): ?>
<div class="warning-banner">
    <i data-lucide="siren"></i>
    <div>
        <strong>For a real emergency, call 112 or seek immediate medical attention.</strong>
        <p>Demo alerts do not contact an ASHA worker, doctor, ambulance, or emergency service.</p>
    </div>
    <a href="tel:112" class="danger-button">
        <i data-lucide="phone"></i>
        Call 112
    </a>
</div>
<div class="section-actions">
    <h2><?php echo count($activeAlerts); ?> open requests</h2>
    <button class="primary-button" onclick="openModal('emergency')">
        <i data-lucide="plus"></i>
        Create demo alert
    </button>
</div>
<div class="emergency-grid">
    <?php foreach ($activeAlerts as $a): 
        $p = null;
        foreach ($data['patients'] as $pat) {
            if ($pat['id'] === $a['patientId']) { $p = $pat; break; }
        }
        if (!$p) continue;
    ?>
    <div class="emergency-item <?php echo ($a['urgency'] === 'High') ? 'critical' : ''; ?>">
        <div class="emergency-item-top">
            <span class="badge <?php echo ($a['urgency'] === 'High') ? 'red' : 'amber'; ?>">
                <?php echo ($a['urgency'] === 'High') ? 'High priority' : htmlspecialchars($a['urgency']); ?>
            </span>
            <span class="muted">Demo alert</span>
        </div>
        <h3><?php echo htmlspecialchars($p['name']); ?></h3>
        <p><?php echo htmlspecialchars($a['condition']); ?></p>
        <small>
            <i data-lucide="map-pin"></i>
            <?php echo htmlspecialchars($p['village']); ?> village
        </small>
        <button class="text-button" onclick="openRespond(<?php echo (int) $a['id']; ?>, <?php echo htmlspecialchars(json_encode($p['name']), ENT_QUOTES); ?>, <?php echo htmlspecialchars(json_encode($a['condition']), ENT_QUOTES); ?>)">
            Review alert <i data-lucide="arrow-right"></i>
        </button>
    </div>
    <?php endforeach; ?>
</div>
<?php if (empty($activeAlerts)): ?>
<div class="empty">
    <i data-lucide="shield-check"></i>
    <h2>No open alerts</h2>
    <p>All demo requests have been reviewed.</p>
</div>
<?php endif; ?>
<section class="panel resolved-panel">
    <div class="panel-header">
        <h2>Resolved requests <span class="count"><?php echo count($resolved); ?></span></h2>
    </div>
    <?php foreach ($resolved as $a): 
        $p = null;
        foreach ($data['patients'] as $pat) {
            if ($pat['id'] === $a['patientId']) { $p = $pat; break; }
        }
        if (!$p) continue;
    ?>
    <div class="resolved-row">
        <i data-lucide="check-check"></i>
        <strong><?php echo htmlspecialchars($p['name']); ?></strong>
        <span><?php echo htmlspecialchars($a['condition']); ?></span>
        <span class="badge green">Resolved</span>
    </div>
    <?php endforeach; ?>
    <?php if (empty($resolved)): ?>
    <p class="empty-small">Resolved requests appear here after review.</p>
    <?php endif; ?>
</section>
<?php endif; ?>
