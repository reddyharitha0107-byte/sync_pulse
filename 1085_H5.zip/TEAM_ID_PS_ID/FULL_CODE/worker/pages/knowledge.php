<?php
require_once __DIR__ . '/../../includes/data.php';
$data = getSeedData();
$articles = getArticles();
$query = $_GET['q'] ?? '';
$lang = $_GET['lang'] ?? 'English';
?>
<div class="knowledge-banner">
    <i data-lucide="book-open" style="width:34px;height:34px;"></i>
    <div>
        <h2>Trusted basics. Always within reach.</h2>
        <p>
            Search works without a network in English, Hindi and Telugu. General education based on WHO and India NHM
            public-health principles. Demo summaries need local clinical review.
        </p>
    </div>
    <span class="badge green">
        <i data-lucide="download"></i>4 offline guides
    </span>
</div>
<div class="table-toolbar knowledge-search">
    <label class="search-input">
        <i data-lucide="search"></i>
        <input aria-label="Search health guides" placeholder="Search first aid, pregnancy, fever, safe water…" value="<?php echo htmlspecialchars($query); ?>" onkeyup="searchGuides(this.value)">
    </label>
    <select aria-label="Guide language" onchange="changeLanguage(this.value)">
        <option <?php echo ($lang === 'English') ? 'selected' : ''; ?>>English</option>
        <option <?php echo ($lang === 'हिन्दी') ? 'selected' : ''; ?>>हिन्दी</option>
        <option <?php echo ($lang === 'తెలుగు') ? 'selected' : ''; ?>>తెలుగు</option>
    </select>
</div>
<div class="article-grid">
    <?php
    $icons = ['heart-pulse', 'heart', 'stethoscope', 'droplets'];
    $i = 0;
    foreach ($articles as $a) {
    ?>
    <button class="article-card panel" data-search="<?php echo htmlspecialchars(mb_strtolower($a['title'] . ' ' . $a['category'] . ' ' . $a['body'] . ' ' . $a['hi'] . ' ' . $a['te'])); ?>" onclick="openArticle('<?php echo $a['id']; ?>')">
        <span class="article-icon tone-<?php echo $i % 4; ?>">
            <i data-lucide="<?php echo $icons[$i % 4]; ?>"></i>
        </span>
        <span class="eyebrow"><?php echo $a['category']; ?></span>
        <h2><?php echo htmlspecialchars($a['title']); ?></h2>
        <p>
            <?php 
            if ($lang === 'हिन्दी') {
                echo htmlspecialchars(mb_substr($a['hi'], 0, 95)) . '…';
            } elseif ($lang === 'తెలుగు') {
                echo htmlspecialchars(mb_substr($a['te'], 0, 95)) . '…';
            } else {
                echo htmlspecialchars(mb_substr($a['body'], 0, 125)) . '…';
            }
            ?>
        </p>
        <div>
            <span><?php echo $a['time']; ?> · Saved offline</span>
            <i data-lucide="arrow-right"></i>
        </div>
    </button>
    <?php $i++; } ?>
</div>
<div class="empty" id="guidesEmpty" style="display:none;">
    <i data-lucide="search-x"></i>
    <h3>No guides found</h3>
    <p>Try “fever” or “first aid”.</p>
</div>
<div class="warning-banner">
    <i data-lucide="shield-check"></i>
    <p>
        Seek immediate medical attention or contact a doctor for
        serious symptoms. These guides do not diagnose conditions
        or replace professional care.
    </p>
</div>
