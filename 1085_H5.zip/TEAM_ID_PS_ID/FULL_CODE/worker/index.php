<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/data.php';
require_worker();

$worker = current_worker();
$genderOptions = ['Female', 'Male', 'Other'];
$categoryOptions = ['General care', 'Maternal care', 'Child health', 'Chronic care'];

$isValidDate = function (string $date): bool {
    $parsed = DateTime::createFromFormat('Y-m-d', $date);
    return $parsed !== false && $parsed->format('Y-m-d') === $date;
};
$isValidTime = function (string $time): bool {
    $parsed = DateTime::createFromFormat('H:i', $time);
    return $parsed !== false && $parsed->format('H:i') === $time;
};

$ownsPatient = function (int $patientId) use ($worker): bool {
    $statement = db()->prepare(
        'SELECT id FROM patients
         WHERE id = ? AND status = "active"
           AND (assigned_worker_id = ? OR created_by_worker_id = ?)'
    );
    $statement->execute([$patientId, $worker['id'], $worker['id']]);
    return (bool) $statement->fetch();
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_patient') {
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $phone = trim($_POST['phone'] ?? '');
        $age = (int) ($_POST['age'] ?? 0);
        $gender = $_POST['gender'] ?? '';
        $village = trim($_POST['village'] ?? '');
        $category = $_POST['category'] ?? '';
        $history = trim($_POST['history'] ?? '');
        $family = trim($_POST['family'] ?? '');

        $errors = [];
        if ($name === '') {
            $errors[] = 'Patient name is required.';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'A valid patient email is required.';
        }
        if ($phone === '') {
            $errors[] = 'Phone number is required.';
        }
        if ($age < 1 || $age > 120) {
            $errors[] = 'Enter a valid age.';
        }
        if (!in_array($gender, $genderOptions, true)) {
            $errors[] = 'Choose a gender.';
        }
        if ($village === '') {
            $errors[] = 'Village is required.';
        }
        if (!in_array($category, $categoryOptions, true)) {
            $errors[] = 'Choose a care category.';
        }

        if (!$errors) {
            try {
                $statement = db()->prepare(
                    'INSERT INTO patients
                        (name, email, phone, age, gender, village, category, history, family, assigned_worker_id, created_by_worker_id, status)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active")'
                );
                $statement->execute([
                    $name,
                    $email,
                    $phone,
                    $age,
                    $gender,
                    $village,
                    $category,
                    $history !== '' ? $history : null,
                    $family !== '' ? $family : null,
                    $worker['id'],
                    $worker['id'],
                ]);
                flash('success', $name . ' was added to your community.');
            } catch (PDOException $error) {
                if ((int) $error->getCode() === 23000) {
                    flash('error', 'A patient with that email already exists.');
                } else {
                    flash('error', 'Could not add the patient. Please try again.');
                }
            }
        } else {
            flash('error', implode(' ', $errors));
        }

        redirect_to('index.php?view=Patients');
    }

    if ($action === 'schedule_visit') {
        $patientId = (int) ($_POST['patient_id'] ?? 0);
        $date = $_POST['visit_date'] ?? '';
        $time = $_POST['visit_time'] ?? '';
        $type = trim($_POST['type'] ?? '');
        $notes = trim($_POST['notes'] ?? '');

        if (!$ownsPatient($patientId)) {
            flash('error', 'Choose one of your registered patients.');
            redirect_to('index.php?view=Overview');
        }
        if ($date === '' || $time === '' || $type === ''
            || !$isValidDate($date) || !$isValidTime($time)) {
            flash('error', 'Enter a valid date, time, and visit type.');
            redirect_to('index.php?view=Overview');
        }

        $statement = db()->prepare(
            'INSERT INTO visits (patient_id, worker_id, visit_date, visit_time, type, status, notes)
             VALUES (?, ?, ?, ?, ?, "Upcoming", ?)'
        );
        $statement->execute([$patientId, $worker['id'], $date, $time, $type, $notes !== '' ? $notes : null]);
        flash('success', 'Visit scheduled successfully.');
        redirect_to('index.php?view=Alerts&filter=Upcoming');
    }

    if ($action === 'create_alert') {
        $patientId = (int) ($_POST['patient_id'] ?? 0);
        $condition = trim($_POST['condition'] ?? '');
        $urgency = $_POST['urgency'] ?? 'Help request';

        if (!$ownsPatient($patientId)) {
            flash('error', 'Choose one of your registered patients.');
            redirect_to('index.php?view=Emergency');
        }
        if ($condition === '') {
            flash('error', 'Describe the condition before creating an alert.');
            redirect_to('index.php?view=Emergency');
        }
        if (!in_array($urgency, ['High', 'Medium', 'Help request'], true)) {
            $urgency = 'Help request';
        }

        $statement = db()->prepare(
            'INSERT INTO alerts (patient_id, worker_id, condition_text, urgency) VALUES (?, ?, ?, ?)'
        );
        $statement->execute([$patientId, $worker['id'], $condition, $urgency]);
        flash('success', 'Alert created and added to your emergency queue.');
        redirect_to('index.php?view=Emergency');
    }

    if ($action === 'resolve_alert') {
        $alertId = (int) ($_POST['alert_id'] ?? 0);
        $statement = db()->prepare(
            'UPDATE alerts
             SET resolved = 1, resolved_by = ?, resolved_at = NOW()
             WHERE id = ? AND worker_id = ? AND resolved = 0'
        );
        $statement->execute([$worker['id'], $alertId, $worker['id']]);
        flash($statement->rowCount() ? 'success' : 'error', $statement->rowCount() ? 'Alert marked as resolved.' : 'Alert could not be found.');
        redirect_to('index.php?view=Emergency');
    }

    if ($action === 'complete_visit') {
        $visitId = (int) ($_POST['visit_id'] ?? 0);
        $statement = db()->prepare(
            'UPDATE visits SET status = "Completed" WHERE id = ? AND worker_id = ? AND status <> "Cancelled"'
        );
        $statement->execute([$visitId, $worker['id']]);
        flash($statement->rowCount() ? 'success' : 'error', $statement->rowCount() ? 'Visit marked as completed.' : 'Visit could not be found.');
        redirect_to('index.php?view=Alerts');
    }

    if ($action === 'cancel_visit') {
        $visitId = (int) ($_POST['visit_id'] ?? 0);
        $statement = db()->prepare(
            'UPDATE visits SET status = "Cancelled" WHERE id = ? AND worker_id = ? AND status = "Upcoming"'
        );
        $statement->execute([$visitId, $worker['id']]);
        flash($statement->rowCount() ? 'success' : 'error', $statement->rowCount() ? 'Visit cancelled.' : 'Visit could not be cancelled.');
        redirect_to('index.php?view=Alerts');
    }

    if ($action === 'update_patient') {
        $patientId = (int) ($_POST['patient_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $age = (int) ($_POST['age'] ?? 0);
        $gender = $_POST['gender'] ?? '';
        $village = trim($_POST['village'] ?? '');
        $category = $_POST['category'] ?? '';
        $history = trim($_POST['history'] ?? '');
        $family = trim($_POST['family'] ?? '');

        if (!$ownsPatient($patientId)) {
            flash('error', 'Patient not found.');
            redirect_to('index.php?view=Patients');
        }

        if ($name === '' || $phone === '' || $village === '' || $age < 1 || $age > 120
            || !in_array($gender, $genderOptions, true)
            || !in_array($category, $categoryOptions, true)) {
            flash('error', 'Please complete all required patient fields.');
            redirect_to('index.php?view=Patients');
        }

        $statement = db()->prepare(
            'UPDATE patients
             SET name = ?, phone = ?, age = ?, gender = ?, village = ?, category = ?, history = ?, family = ?
             WHERE id = ?'
        );
        $statement->execute([
            $name,
            $phone,
            $age,
            $gender,
            $village,
            $category,
            $history !== '' ? $history : null,
            $family !== '' ? $family : null,
            $patientId,
        ]);
        flash('success', 'Patient profile updated.');
        redirect_to('index.php?view=Patients');
    }

    redirect_to('index.php');
}

$views = [
    'Overview' => 'overview.php',
    'Search' => 'knowledge.php',
    'Patients' => 'patients.php',
    'Emergency' => 'alerts.php',
    'Alerts' => 'alerts.php',
    'Cure' => 'knowledge.php',
    'Metrics' => 'metrics.php',
];

$view = $_GET['view'] ?? 'Overview';
if (!isset($views[$view])) {
    $view = 'Overview';
}
$pageTitle = $view . ' · SyncPulse Worker';
$profileData = getSeedData();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="SyncPulse ASHA worker workspace.">
    <link rel="manifest" href="../assets/manifest.webmanifest">
    <link rel="icon" href="../assets/icon.svg" type="image/svg+xml">
    <link rel="icon" href="../assets/favicon.ico" sizes="any">
    <link rel="apple-touch-icon" href="../assets/icon-192.png">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="app-shell">
        <?php include __DIR__ . '/components/sidebar.php'; ?>
        <div class="main-shell">
            <?php include __DIR__ . '/components/topbar.php'; ?>
            <main>
                <?php include __DIR__ . '/components/offline-notice.php'; ?>
                <?php render_flashes(); ?>
                <?php include __DIR__ . '/pages/' . $views[$view]; ?>
            </main>
        </div>
    </div>

    <?php include __DIR__ . '/components/modals.php'; ?>

    <script>
        window.SYNCPULSE_PROFILE = <?php echo json_encode([
            'patients' => array_values($profileData['patients']),
            'visits' => $profileData['visits'],
            'categories' => $categoryOptions,
            'genders' => $genderOptions,
        ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    </script>
    <script src="https://unpkg.com/lucide@1.64.0/dist/umd/lucide.js"></script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
