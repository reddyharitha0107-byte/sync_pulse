<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

if (current_worker()) {
    redirect_to('index.php');
}

$error = '';
$workerCode = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $workerCode = strtoupper(trim($_POST['worker_code'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($workerCode !== '' && $password !== '') {
        $statement = db()->prepare('SELECT * FROM workers WHERE worker_code = ? LIMIT 1');
        $statement->execute([$workerCode]);
        $worker = $statement->fetch();

        if ($worker && $worker['status'] === 'active' && password_verify($password, $worker['password_hash'])) {
            login_user([
                'id' => $worker['id'],
                'role' => 'worker',
                'name' => $worker['name'],
                'code' => $worker['worker_code'],
                'email' => $worker['email'],
                'village' => $worker['village'],
            ]);
            redirect_to('index.php');
        }

        if ($worker && $worker['status'] !== 'active') {
            $error = 'This worker account is inactive. Contact the super admin.';
        } else {
            $error = 'Incorrect worker ID or password.';
        }
    } else {
        $error = 'Enter your worker ID and password to continue.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ASHA Worker Login · SyncPulse</title>
    <link rel="manifest" href="../assets/manifest.webmanifest">
    <link rel="icon" href="../assets/icon.svg" type="image/svg+xml">
    <link rel="icon" href="../assets/favicon.ico" sizes="any">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="auth-body">
    <main class="auth-page">
        <div class="auth-card">
            <a class="auth-brand" href="../index.php">
                <span class="brand-mark"><i data-lucide="activity"></i></span>
                <span>Sync<span class="brand-pulse">Pulse</span><small>CONNECTED COMMUNITY CARE</small></span>
            </a>
            <h1>ASHA Worker Login</h1>
            <p>Sign in to your community care workspace. Worker accounts are created by the super admin.</p>

            <?php if ($error !== ''): ?>
                <div class="auth-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form class="app-form" method="post">
                <?php echo csrf_field(); ?>
                <label>
                    Worker ID
                    <input type="text" name="worker_code" value="<?php echo htmlspecialchars($workerCode); ?>" autocomplete="username" required>
                </label>
                <label>
                    Password
                    <input type="password" name="password" autocomplete="current-password" required>
                </label>
                <div class="form-actions">
                    <button class="primary-button" type="submit">Sign in to workspace</button>
                </div>
            </form>

            <a class="auth-back" href="../index.php"><i data-lucide="arrow-left"></i> Back to home</a>
            <div class="auth-demo">
                Demo worker: <strong>DEMO-ASHA-001</strong> / <strong>Worker@123</strong><br>
                Worker accounts can only be created by the super admin.
            </div>
        </div>
    </main>

    <script src="https://unpkg.com/lucide@1.64.0/dist/umd/lucide.js"></script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
