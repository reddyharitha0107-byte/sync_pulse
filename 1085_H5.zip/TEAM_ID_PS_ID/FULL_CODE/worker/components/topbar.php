<?php
$worker = function_exists('current_worker') ? current_worker() : null;
$workerName = $worker['name'] ?? 'ASHA Worker';
$workerInitials = function_exists('initials') ? initials($workerName) : 'SK';
?>
<header class="topbar">
    <div class="breadcrumb">
        <button class="icon-button mobile-menu" aria-label="Open navigation" onclick="toggleSidebar()">
            <i data-lucide="menu"></i>
        </button>
        <span>My workspace</span>
        <i data-lucide="chevron-right"></i>
        <strong><?php echo htmlspecialchars($view); ?></strong>
    </div>
    <div class="top-actions">
        <span class="connection" id="connectionStatus">
            <i data-lucide="wifi"></i>
            <span>Online</span>
        </span>
        <button class="sync-button" onclick="syncData()">
            <i data-lucide="refresh-cw"></i>
            <span id="syncStatus">Refresh data</span>
        </button>
        <span class="top-divider"></span>
        <button class="language-button" onclick="openModal('language')">
            <i data-lucide="globe"></i>
            EN
            <i data-lucide="chevron-right"></i>
        </button>
        <button class="notification icon-button" aria-label="View alerts" onclick="window.location.href='?view=Emergency'">
            <i data-lucide="bell"></i>
            <i></i>
        </button>
        <button class="avatar mini-avatar" aria-label="Sign out" title="Sign out" onclick="window.location.href='logout.php'">
            <?php echo htmlspecialchars($workerInitials); ?>
        </button>
    </div>
</header>
