<?php
require_once __DIR__ . '/../../includes/data.php';
$modalData = getSeedData();
$modalPatients = $modalData['patients'];
$categoryOptions = ['General care', 'Maternal care', 'Child health', 'Chronic care'];
?>
<!-- Modals -->
<div id="modal-overlay" class="modal-overlay" onclick="closeModal()"></div>

<div id="modal-language" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Language</h2>
        <p>Select your preferred language</p>
        <div class="app-form">
            <button class="secondary-button" style="justify-content: flex-start;" onclick="closeModal()">English</button>
            <button class="secondary-button" style="justify-content: flex-start;" onclick="closeModal()">हिन्दी (Hindi)</button>
            <button class="secondary-button" style="justify-content: flex-start;" onclick="closeModal()">తెలుగు (Telugu)</button>
        </div>
    </div>
</div>

<div id="modal-add" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Add patient</h2>
        <p>Create a patient record in your community. The patient can also self-register.</p>
        <form class="app-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="add_patient">
            <div class="form-grid">
                <label>Full name<input type="text" name="name" required></label>
                <label>Age<input type="number" name="age" min="1" max="120" required></label>
            </div>
            <div class="form-grid">
                <label>Gender
                    <select name="gender" required>
                        <option>Female</option>
                        <option>Male</option>
                        <option>Other</option>
                    </select>
                </label>
                <label>Village<input type="text" name="village" value="<?php echo htmlspecialchars(current_worker()['village'] ?? ''); ?>" required></label>
            </div>
            <div class="form-grid">
                <label>Email address<input type="email" name="email" required></label>
                <label>Phone<input type="tel" name="phone" required></label>
            </div>
            <label>Care category
                <select name="category">
                    <?php foreach ($categoryOptions as $category): ?>
                        <option><?php echo htmlspecialchars($category); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Medical history<textarea name="history"></textarea></label>
            <label>Family details<input type="text" name="family" placeholder="e.g. 4 members · Husband and 2 children"></label>
            <div class="form-actions">
                <button class="primary-button" type="submit">Add patient</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="modal-emergency" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Create alert</h2>
        <p>Create a follow-up request for one of your patients.</p>
        <form class="app-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="create_alert">
            <label>Patient
                <select name="patient_id" required>
                    <?php foreach ($modalPatients as $patient): ?>
                        <option value="<?php echo (int) $patient['id']; ?>">
                            <?php echo htmlspecialchars($patient['name'] . ' · ' . $patient['village']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Condition<textarea name="condition" required></textarea></label>
            <label>Urgency
                <select name="urgency">
                    <option>High</option>
                    <option>Medium</option>
                    <option>Help request</option>
                </select>
            </label>
            <div class="form-actions">
                <button class="danger-button" type="submit">Create alert</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="modal-schedule" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Schedule visit</h2>
        <form class="app-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="schedule_visit">
            <label>Patient
                <select name="patient_id" required>
                    <?php foreach ($modalPatients as $patient): ?>
                        <option value="<?php echo (int) $patient['id']; ?>">
                            <?php echo htmlspecialchars($patient['name'] . ' · ' . $patient['village']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="form-grid">
                <label>Date<input type="date" name="visit_date" value="<?php echo date('Y-m-d'); ?>" required></label>
                <label>Time<input type="time" name="visit_time" value="09:00" required></label>
            </div>
            <label>Type
                <select name="type">
                    <option>Monthly health visit</option>
                    <option>Antenatal check-up</option>
                    <option>Child health &amp; immunisation</option>
                    <option>Blood pressure follow-up</option>
                    <option>Diabetes follow-up</option>
                    <option>Postnatal check-up</option>
                </select>
            </label>
            <label>Notes<textarea name="notes"></textarea></label>
            <div class="form-actions">
                <button class="primary-button" type="submit">Schedule</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="modal-respond" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Review alert</h2>
        <div class="response-card">
            <strong id="respond-patient">Patient</strong>
            <p id="respond-condition">Condition</p>
        </div>
        <form class="app-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="resolve_alert">
            <input type="hidden" name="alert_id" id="respond-alert-id" value="">
            <p>For a real emergency, call 112 or seek immediate medical attention.</p>
            <div class="form-actions">
                <button class="primary-button" type="submit">Mark resolved</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="modal-profile" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2 id="profile-title">Patient profile</h2>
        <p id="profile-summary">Care information</p>
        <div id="profile-visits" class="profile-visits"></div>
        <form class="app-form" method="post" style="margin-top: 16px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="update_patient">
            <input type="hidden" name="patient_id" id="profile-patient-id" value="">
            <div class="form-grid">
                <label>Full name<input type="text" name="name" id="profile-name" required></label>
                <label>Phone<input type="tel" name="phone" id="profile-phone" required></label>
            </div>
            <div class="form-grid">
                <label>Age<input type="number" name="age" id="profile-age" min="1" max="120" required></label>
                <label>Gender
                    <select name="gender" id="profile-gender">
                        <option>Female</option>
                        <option>Male</option>
                        <option>Other</option>
                    </select>
                </label>
            </div>
            <div class="form-grid">
                <label>Village<input type="text" name="village" id="profile-village" required></label>
                <label>Care category
                    <select name="category" id="profile-category">
                        <?php foreach ($categoryOptions as $category): ?>
                            <option><?php echo htmlspecialchars($category); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <label>Medical history<textarea name="history" id="profile-history"></textarea></label>
            <label>Family details<input type="text" name="family" id="profile-family"></label>
            <div class="form-actions">
                <button class="primary-button" type="submit">Save profile</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="modal-support" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Help &amp; support</h2>
        <div class="app-form">
            <div class="response-card">
                <strong>For emergencies</strong>
                <p>Call 112 (India) or your local emergency number.</p>
            </div>
            <p>Worker accounts are managed by the super admin. Contact them if you cannot sign in.</p>
            <div class="form-actions">
                <button class="secondary-button" onclick="closeModal()">Close</button>
            </div>
        </div>
    </div>
</div>
