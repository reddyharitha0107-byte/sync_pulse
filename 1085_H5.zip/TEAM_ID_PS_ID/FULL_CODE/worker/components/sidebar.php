<?php
require_once __DIR__ . '/../../includes/data.php';
$data = getSeedData();
$articles = getArticles();
$worker = function_exists('current_worker') ? current_worker() : null;
$workerName = $worker['name'] ?? 'ASHA Worker';
$workerInitials = initials($workerName);
$workerVillage = $worker['village'] ?? 'Community';
?>
<aside class="sidebar" id="sidebar">
    <button class="brand" onclick="window.location.href='?view=Overview'">
        <span class="brand-mark">
            <i data-lucide="activity"></i>
        </span>
        <span>
            Sync<span class="brand-pulse">Pulse</span>
            <small>CONNECTED COMMUNITY CARE</small>
        </span>
    </button>
    <div class="workspace-label">
        ASHA WORKSPACE <span>LIVE</span>
    </div>
    <nav>
        <?php
        $modules = [
            ['name' => 'Overview', 'icon' => 'layout-dashboard'],
            ['name' => 'Search', 'icon' => 'search'],
            ['name' => 'Patients', 'icon' => 'users'],
            ['name' => 'Emergency', 'icon' => 'siren'],
            ['name' => 'Alerts', 'icon' => 'bell'],
            ['name' => 'Cure', 'icon' => 'heart-pulse'],
            ['name' => 'Metrics', 'icon' => 'chart-no-axes-combined'],
        ];
        $activeAlerts = array_filter($data['alerts'], function($a) { return !$a['resolved']; });
        foreach ($modules as $m) {
            $active = ($view === $m['name']) ? 'active' : '';
        ?>
        <button class="nav-item <?php echo $active; ?>" onclick="window.location.href='?view=<?php echo urlencode($m['name']); ?>'">
            <i data-lucide="<?php echo $m['icon']; ?>"></i>
            <span><?php echo $m['name']; ?></span>
            <?php if ($m['name'] === 'Emergency' && count($activeAlerts) > 0): ?>
                <b><?php echo count($activeAlerts); ?></b>
            <?php endif; ?>
            <?php if ($m['name'] === 'Alerts'): ?>
                <span class="nav-dot"></span>
            <?php endif; ?>
        </button>
        <?php } ?>
    </nav>
    <div class="sidebar-bottom">
        <div class="offline-card">
            <i data-lucide="database"></i>
            <h4>Database connected.</h4>
            <p>Your patients, visits, and alerts are stored in MySQL.</p>
            <span>
                <span class="status-dot"></span>
                Live workspace
            </span>
        </div>
        <button class="nav-item" onclick="window.location.href='../patient/'">
            <i data-lucide="heart"></i>
            Patient portal
            <i data-lucide="arrow-up-right"></i>
        </button>
        <button class="nav-item" onclick="openModal('support')">
            <i data-lucide="circle-help"></i>
            Help & support
        </button>
        <div class="worker">
            <div class="avatar worker-avatar"><?php echo htmlspecialchars($workerInitials); ?></div>
            <div>
                <strong><?php echo htmlspecialchars($workerName); ?></strong>
                <small><?php echo htmlspecialchars($worker['code'] ?? 'Worker'); ?> · <?php echo htmlspecialchars($workerVillage); ?></small>
            </div>
            <button class="icon-button" aria-label="Sign out" title="Sign out" onclick="window.location.href='logout.php'">
                <i data-lucide="log-out"></i>
            </button>
        </div>
    </div>
</aside>
