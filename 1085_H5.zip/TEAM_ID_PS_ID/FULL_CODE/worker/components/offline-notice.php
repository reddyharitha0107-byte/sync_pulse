<div class="offline-notice" role="status">
    <strong>Offline access ready</strong>
    <p>Previously loaded pages and health guides remain readable without internet. Creating visits, alerts, or profile changes requires a connection. No emergency dispatch.</p>
</div>
<div class="warning-banner" style="display:none;" id="storageError">
    Device storage is unavailable. Changes cannot survive a page reload. Use a browser with IndexedDB enabled.
</div>
