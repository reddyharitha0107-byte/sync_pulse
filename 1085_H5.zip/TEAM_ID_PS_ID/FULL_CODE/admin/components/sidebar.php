<?php
require_once __DIR__ . '/../../includes/data.php';
$admin = current_admin();
$adminName = $admin['name'] ?? 'Super Admin';
$adminInitials = initials($adminName);
$data = getSeedData('all');
$activeAlerts = array_filter($data['alerts'], function ($alert) { return !$alert['resolved']; });
?>
<aside class="sidebar" id="sidebar">
    <button class="brand" onclick="window.location.href='?view=Overview'">
        <span class="brand-mark"><i data-lucide="activity"></i></span>
        <span>
            Sync<span class="brand-pulse">Pulse</span>
            <small>CONNECTED COMMUNITY CARE</small>
        </span>
    </button>
    <div class="workspace-label">
        SUPER ADMIN <span>DB</span>
    </div>
    <nav>
        <?php
        $modules = [
            ['name' => 'Overview', 'icon' => 'layout-dashboard'],
            ['name' => 'Workers', 'icon' => 'stethoscope'],
            ['name' => 'Patients', 'icon' => 'users'],
            ['name' => 'Visits', 'icon' => 'calendar-days'],
            ['name' => 'Alerts', 'icon' => 'siren'],
        ];
        foreach ($modules as $module) {
            $active = ($view === $module['name']) ? 'active' : '';
        ?>
        <button class="nav-item <?php echo $active; ?>" onclick="window.location.href='?view=<?php echo urlencode($module['name']); ?>'">
            <i data-lucide="<?php echo $module['icon']; ?>"></i>
            <span><?php echo $module['name']; ?></span>
            <?php if ($module['name'] === 'Alerts' && count($activeAlerts) > 0): ?>
                <b><?php echo count($activeAlerts); ?></b>
            <?php endif; ?>
        </button>
        <?php } ?>
    </nav>
    <div class="sidebar-bottom">
        <div class="offline-card">
            <i data-lucide="database"></i>
            <h4>MySQL connected.</h4>
            <p>Workers, patients, visits, and alerts are stored in the database.</p>
            <span>
                <span class="status-dot"></span>
                Live data
            </span>
        </div>
        <button class="nav-item" onclick="window.location.href='../worker/login.php'">
            <i data-lucide="stethoscope"></i>
            Worker login
            <i data-lucide="arrow-up-right"></i>
        </button>
        <button class="nav-item" onclick="window.location.href='../patient/login.php'">
            <i data-lucide="heart"></i>
            Patient portal
            <i data-lucide="arrow-up-right"></i>
        </button>
        <div class="worker">
            <div class="avatar worker-avatar"><?php echo htmlspecialchars($adminInitials); ?></div>
            <div>
                <strong><?php echo htmlspecialchars($adminName); ?></strong>
                <small>Super administrator</small>
            </div>
            <button class="icon-button" aria-label="Sign out" title="Sign out" onclick="window.location.href='logout.php'">
                <i data-lucide="log-out"></i>
            </button>
        </div>
    </div>
</aside>
