<?php
$admin = current_admin();
$adminName = $admin['name'] ?? 'Super Admin';
$adminInitials = initials($adminName);
?>
<header class="topbar">
    <div class="breadcrumb">
        <button class="icon-button mobile-menu" aria-label="Open navigation" onclick="toggleSidebar()">
            <i data-lucide="menu"></i>
        </button>
        <span>Super admin</span>
        <i data-lucide="chevron-right"></i>
        <strong><?php echo htmlspecialchars($view); ?></strong>
    </div>
    <div class="top-actions">
        <span class="connection">
            <i data-lucide="database"></i>
            <span>MySQL</span>
        </span>
        <span class="top-divider"></span>
        <span class="patient-chip">
            <span class="avatar"><?php echo htmlspecialchars($adminInitials); ?></span>
            <span><?php echo htmlspecialchars($adminName); ?></span>
        </span>
        <button class="avatar mini-avatar" aria-label="Sign out" title="Sign out" onclick="window.location.href='logout.php'">
            <?php echo htmlspecialchars($adminInitials); ?>
        </button>
    </div>
</header>
