<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

if (current_admin()) {
    redirect_to('index.php');
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($email !== '' && $password !== '') {
        $statement = db()->prepare('SELECT * FROM admins WHERE email = ? LIMIT 1');
        $statement->execute([$email]);
        $admin = $statement->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            login_user([
                'id' => $admin['id'],
                'role' => 'admin',
                'name' => $admin['name'],
                'email' => $admin['email'],
            ]);
            redirect_to('index.php');
        }
    }

    $error = 'Incorrect email or password.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Login · SyncPulse</title>
    <link rel="manifest" href="../assets/manifest.webmanifest">
    <link rel="icon" href="../assets/icon.svg" type="image/svg+xml">
    <link rel="icon" href="../assets/favicon.ico" sizes="any">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="auth-body">
    <main class="auth-page">
        <div class="auth-card">
            <a class="auth-brand" href="../index.php">
                <span class="brand-mark"><i data-lucide="shield-check"></i></span>
                <span>Sync<span class="brand-pulse">Pulse</span><small>SUPER ADMIN</small></span>
            </a>
            <h1>Super Admin Login</h1>
            <p>Register ASHA workers, review the community, and manage access.</p>

            <?php if ($error !== ''): ?>
                <div class="auth-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form class="app-form" method="post">
                <?php echo csrf_field(); ?>
                <label>
                    Email address
                    <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" autocomplete="username" required>
                </label>
                <label>
                    Password
                    <input type="password" name="password" autocomplete="current-password" required>
                </label>
                <div class="form-actions">
                    <button class="primary-button" type="submit">Sign in</button>
                </div>
            </form>

            <a class="auth-back" href="../index.php"><i data-lucide="arrow-left"></i> Back to home</a>
            <div class="auth-demo">
                Demo super admin: <strong>admin@syncpulse.local</strong> / <strong>Admin@123</strong>
            </div>
        </div>
    </main>

    <script src="https://unpkg.com/lucide@1.64.0/dist/umd/lucide.js"></script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
