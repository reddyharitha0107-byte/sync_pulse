<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/data.php';
require_admin();

$admin = current_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_worker') {
        $code = strtoupper(trim($_POST['worker_code'] ?? ''));
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $phone = trim($_POST['phone'] ?? '');
        $village = trim($_POST['village'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['password_confirm'] ?? '';

        $errors = [];
        if ($code === '' || !preg_match('/^[A-Z0-9-]{3,50}$/', $code)) {
            $errors[] = 'Worker ID must be 3-50 characters using letters, numbers, or dashes.';
        }
        if ($name === '') {
            $errors[] = 'Worker name is required.';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'A valid email address is required.';
        }
        if ($village === '') {
            $errors[] = 'Village is required.';
        }
        if (strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        } elseif ($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        }

        if (!$errors) {
            try {
                $statement = db()->prepare(
                    'INSERT INTO workers (worker_code, name, email, phone, village, password_hash, status, created_by)
                     VALUES (?, ?, ?, ?, ?, ?, "active", ?)'
                );
                $statement->execute([
                    $code,
                    $name,
                    $email,
                    $phone !== '' ? $phone : null,
                    $village,
                    password_hash($password, PASSWORD_DEFAULT),
                    $admin['id'],
                ]);
                flash('success', 'Worker ' . $name . ' registered successfully.');
            } catch (PDOException $error) {
                if ((int) $error->getCode() === 23000) {
                    flash('error', 'That worker ID or email address is already registered.');
                } else {
                    flash('error', 'Could not register the worker. Please try again.');
                }
            }
        } else {
            flash('error', implode(' ', $errors));
        }

        redirect_to('index.php?view=Workers');
    }

    if ($action === 'toggle_worker') {
        $workerId = (int) ($_POST['worker_id'] ?? 0);
        $statement = db()->prepare('SELECT id, name, status FROM workers WHERE id = ?');
        $statement->execute([$workerId]);
        $worker = $statement->fetch();

        if ($worker) {
            $newStatus = $worker['status'] === 'active' ? 'inactive' : 'active';
            $update = db()->prepare('UPDATE workers SET status = ? WHERE id = ?');
            $update->execute([$newStatus, $workerId]);
            flash('success', $worker['name'] . ' is now ' . $newStatus . '.');
        } else {
            flash('error', 'Worker not found.');
        }

        redirect_to('index.php?view=Workers');
    }

    redirect_to('index.php');
}

$views = ['Overview', 'Workers', 'Patients', 'Visits', 'Alerts'];
$view = $_GET['view'] ?? 'Overview';
if (!in_array($view, $views, true)) {
    $view = 'Overview';
}

$data = getSeedData('all');
$workers = db()->query(
    'SELECT w.*, a.name AS created_by_name,
            (SELECT COUNT(*) FROM patients p WHERE p.assigned_worker_id = w.id AND p.status = "active") AS patient_count
     FROM workers w
     LEFT JOIN admins a ON a.id = w.created_by
     ORDER BY w.created_at DESC, w.id DESC'
)->fetchAll();

$activeWorkers = array_filter($workers, function ($worker) { return $worker['status'] === 'active'; });
$today = date('Y-m-d');
$todayVisits = array_filter($data['visits'], function ($visit) use ($today) { return $visit['date'] === $today; });
$openAlerts = array_filter($data['alerts'], function ($alert) { return !$alert['resolved']; });
$pageTitle = $view . ' · SyncPulse Super Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="SyncPulse super admin workspace.">
    <link rel="manifest" href="../assets/manifest.webmanifest">
    <link rel="icon" href="../assets/icon.svg" type="image/svg+xml">
    <link rel="icon" href="../assets/favicon.ico" sizes="any">
    <link rel="apple-touch-icon" href="../assets/icon-192.png">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="app-shell">
        <?php include __DIR__ . '/components/sidebar.php'; ?>
        <div class="main-shell">
            <?php include __DIR__ . '/components/topbar.php'; ?>
            <main>
                <?php render_flashes(); ?>

                <?php if ($view === 'Overview'): ?>
                <div class="page-heading">
                    <div>
                        <div class="eyebrow">SYSTEM CONTROL</div>
                        <h1>Community overview</h1>
                        <p>Workers, patients, visits, and alerts from the database.</p>
                    </div>
                    <div class="heading-actions">
                        <button class="primary-button" onclick="openModal('worker')">
                            <i data-lucide="user-plus"></i>
                            Register worker
                        </button>
                    </div>
                </div>

                <div class="stats-grid">
                    <?php
                    $stats = [
                        ['label' => 'Registered workers', 'value' => count($workers), 'icon' => 'stethoscope', 'change' => count($activeWorkers) . ' active accounts', 'color' => 'teal'],
                        ['label' => 'Patients', 'value' => count($data['patients']), 'icon' => 'users', 'change' => 'Self-registered and worker-added', 'color' => 'green'],
                        ['label' => 'Visits today', 'value' => count($todayVisits), 'icon' => 'calendar-days', 'change' => 'Scheduled home visits', 'color' => 'orange'],
                        ['label' => 'Open alerts', 'value' => count($openAlerts), 'icon' => 'siren', 'change' => 'Waiting for worker follow-up', 'color' => 'rose'],
                    ];
                    foreach ($stats as $stat) {
                    ?>
                    <div class="stat-card">
                        <div class="stat-label">
                            <?php echo $stat['label']; ?>
                            <span class="stat-icon <?php echo $stat['color']; ?>">
                                <i data-lucide="<?php echo $stat['icon']; ?>"></i>
                            </span>
                        </div>
                        <strong><?php echo str_pad((string) $stat['value'], 2, '0', STR_PAD_LEFT); ?></strong>
                        <span class="stat-note <?php echo $stat['color']; ?>"><?php echo $stat['change']; ?></span>
                    </div>
                    <?php } ?>
                </div>

                <div class="dashboard-columns">
                    <section class="panel">
                        <div class="panel-header">
                            <div>
                                <h2>Recently registered workers</h2>
                                <p>Only a super admin can create worker accounts.</p>
                            </div>
                            <button class="text-button" onclick="window.location.href='?view=Workers'">
                                Manage workers <i data-lucide="arrow-right"></i>
                            </button>
                        </div>
                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr><th>Worker</th><th>Village</th><th>Patients</th><th>Status</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($workers, 0, 5) as $i => $worker): ?>
                                    <tr>
                                        <td>
                                            <div class="patient-cell">
                                                <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo htmlspecialchars(initials($worker['name'])); ?></div>
                                                <div>
                                                    <strong><?php echo htmlspecialchars($worker['name']); ?></strong>
                                                    <small><?php echo htmlspecialchars($worker['worker_code']); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($worker['village']); ?></td>
                                        <td><?php echo (int) $worker['patient_count']; ?></td>
                                        <td><span class="badge <?php echo $worker['status'] === 'active' ? 'green' : 'neutral'; ?>"><?php echo ucfirst($worker['status']); ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </section>

                    <section class="panel emergency-panel">
                        <div class="panel-header">
                            <div>
                                <h2><span class="live-dot"></span> Open alerts</h2>
                                <p>Across all registered communities.</p>
                            </div>
                            <span class="count red-count"><?php echo count($openAlerts); ?></span>
                        </div>
                        <?php foreach (array_slice(array_values($openAlerts), 0, 3) as $alert):
                            $patient = $data['patientsById'][$alert['patientId']] ?? null;
                            if (!$patient) continue;
                        ?>
                        <div class="resolved-row">
                            <i data-lucide="siren"></i>
                            <strong><?php echo htmlspecialchars($patient['name']); ?></strong>
                            <span><?php echo htmlspecialchars($alert['condition']); ?></span>
                            <span class="badge <?php echo $alert['urgency'] === 'High' ? 'red' : 'amber'; ?>"><?php echo htmlspecialchars($alert['urgency']); ?></span>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($openAlerts)): ?>
                            <p class="empty-small">No open alerts. All caught up.</p>
                        <?php endif; ?>
                    </section>
                </div>
                <?php endif; ?>

                <?php if ($view === 'Workers'): ?>
                <div class="page-heading">
                    <div>
                        <div class="eyebrow">ACCESS CONTROL</div>
                        <h1>ASHA workers</h1>
                        <p>Create worker accounts and control who can access the workspace.</p>
                    </div>
                    <div class="heading-actions">
                        <button class="primary-button" onclick="openModal('worker')">
                            <i data-lucide="user-plus"></i>
                            Register worker
                        </button>
                    </div>
                </div>
                <section class="panel">
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>Worker</th>
                                    <th>Worker ID</th>
                                    <th>Village</th>
                                    <th>Contact</th>
                                    <th>Patients</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($workers as $i => $worker): ?>
                                <tr>
                                    <td>
                                        <div class="patient-cell">
                                            <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo htmlspecialchars(initials($worker['name'])); ?></div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($worker['name']); ?></strong>
                                                <small>Added <?php echo dateLabel(substr($worker['created_at'], 0, 10)); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($worker['worker_code']); ?></td>
                                    <td><?php echo htmlspecialchars($worker['village']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($worker['email']); ?>
                                        <?php if ($worker['phone']): ?><br><small><?php echo htmlspecialchars($worker['phone']); ?></small><?php endif; ?>
                                    </td>
                                    <td><?php echo (int) $worker['patient_count']; ?></td>
                                    <td><span class="badge <?php echo $worker['status'] === 'active' ? 'green' : 'neutral'; ?>"><?php echo ucfirst($worker['status']); ?></span></td>
                                    <td>
                                        <form method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="action" value="toggle_worker">
                                            <input type="hidden" name="worker_id" value="<?php echo (int) $worker['id']; ?>">
                                            <button class="text-button" type="submit">
                                                <?php echo $worker['status'] === 'active' ? 'Deactivate' : 'Activate'; ?>
                                                <i data-lucide="<?php echo $worker['status'] === 'active' ? 'user-x' : 'user-check'; ?>"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="panel-bottom">
                        <?php echo count($workers); ?> worker accounts <span>Super admin managed</span>
                    </div>
                </section>
                <?php endif; ?>

                <?php if ($view === 'Patients'): ?>
                <div class="page-heading">
                    <div>
                        <div class="eyebrow">COMMUNITY DIRECTORY</div>
                        <h1>All patients</h1>
                        <p>Every patient account and the worker responsible for their care.</p>
                    </div>
                </div>
                <section class="panel">
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr><th>Patient</th><th>Contact</th><th>Village</th><th>Care focus</th><th>ASHA worker</th><th>Registered</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['patients'] as $i => $patient): ?>
                                <tr>
                                    <td>
                                        <div class="patient-cell">
                                            <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo htmlspecialchars(initials($patient['name'])); ?></div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($patient['name']); ?></strong>
                                                <small><?php echo (int) $patient['age']; ?> years · <?php echo htmlspecialchars($patient['gender']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($patient['email']); ?><br><small><?php echo htmlspecialchars($patient['phone']); ?></small></td>
                                    <td><?php echo htmlspecialchars($patient['village']); ?></td>
                                    <td><span class="badge <?php echo $patient['category'] === 'Maternal care' ? 'teal' : ($patient['category'] === 'Child health' ? 'amber' : 'neutral'); ?>"><?php echo htmlspecialchars($patient['category']); ?></span></td>
                                    <td><?php echo htmlspecialchars($patient['worker_name'] ?? 'Unassigned'); ?></td>
                                    <td><?php echo dateLabel(substr($patient['created_at'], 0, 10)); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="panel-bottom">
                        <?php echo count($data['patients']); ?> patient accounts <span>MySQL database</span>
                    </div>
                </section>
                <?php endif; ?>

                <?php if ($view === 'Visits'): ?>
                <div class="page-heading">
                    <div>
                        <div class="eyebrow">CARE DELIVERY</div>
                        <h1>All visits</h1>
                        <p>Scheduled and completed home visits across every community.</p>
                    </div>
                </div>
                <section class="panel">
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr><th>Patient</th><th>ASHA worker</th><th>Date &amp; time</th><th>Visit type</th><th>Status</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['visits'] as $i => $visit):
                                    $patient = $data['patientsById'][$visit['patientId']] ?? null;
                                    if (!$patient) continue;
                                ?>
                                <tr>
                                    <td>
                                        <div class="patient-cell">
                                            <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo htmlspecialchars(initials($patient['name'])); ?></div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($patient['name']); ?></strong>
                                                <small><?php echo htmlspecialchars($patient['village']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($patient['worker_name'] ?? 'Unassigned'); ?></td>
                                    <td><?php echo dateLabel($visit['date']); ?> · <?php echo htmlspecialchars($visit['time']); ?></td>
                                    <td><?php echo htmlspecialchars($visit['type']); ?></td>
                                    <td><span class="badge <?php echo $visit['status'] === 'Completed' ? 'green' : ($visit['status'] === 'Overdue' ? 'red' : 'amber'); ?>"><?php echo htmlspecialchars($visit['status']); ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="panel-bottom">
                        <?php echo count($data['visits']); ?> visits <span>Includes overdue and cancelled records</span>
                    </div>
                </section>
                <?php endif; ?>

                <?php if ($view === 'Alerts'): ?>
                <div class="page-heading">
                    <div>
                        <div class="eyebrow">SUPPORT REQUESTS</div>
                        <h1>All alerts</h1>
                        <p>Emergency and help requests submitted by patients or workers.</p>
                    </div>
                </div>
                <section class="panel">
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr><th>Patient</th><th>Condition</th><th>Urgency</th><th>ASHA worker</th><th>Requested</th><th>Status</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['alerts'] as $i => $alert):
                                    $patient = $data['patientsById'][$alert['patientId']] ?? null;
                                    if (!$patient) continue;
                                ?>
                                <tr>
                                    <td>
                                        <div class="patient-cell">
                                            <div class="avatar tone-<?php echo $i % 4; ?>"><?php echo htmlspecialchars(initials($patient['name'])); ?></div>
                                            <div>
                                                <strong><?php echo htmlspecialchars($patient['name']); ?></strong>
                                                <small><?php echo htmlspecialchars($patient['village']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($alert['condition']); ?></td>
                                    <td><span class="badge <?php echo $alert['urgency'] === 'High' ? 'red' : 'amber'; ?>"><?php echo htmlspecialchars($alert['urgency']); ?></span></td>
                                    <td><?php echo htmlspecialchars($patient['worker_name'] ?? 'Unassigned'); ?></td>
                                    <td><?php echo dateLabel(substr($alert['created'], 0, 10)); ?></td>
                                    <td><span class="badge <?php echo $alert['resolved'] ? 'green' : 'amber'; ?>"><?php echo $alert['resolved'] ? 'Resolved' : 'Open'; ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="panel-bottom">
                        <?php echo count($openAlerts); ?> open · <?php echo count($data['alerts']) - count($openAlerts); ?> resolved <span>MySQL database</span>
                    </div>
                </section>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <div id="modal-overlay" class="modal-overlay" onclick="closeModal()"></div>
    <div id="modal-worker" class="modal">
        <div class="modal-content sync-dialog">
            <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
            <h2>Register ASHA worker</h2>
            <p>The worker signs in with their worker ID and this password.</p>
            <form class="app-form" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add_worker">
                <div class="form-grid">
                    <label>Worker ID<input type="text" name="worker_code" placeholder="ASHA-003" pattern="[A-Za-z0-9-]{3,50}" required></label>
                    <label>Full name<input type="text" name="name" required></label>
                </div>
                <div class="form-grid">
                    <label>Email address<input type="email" name="email" required></label>
                    <label>Phone<input type="tel" name="phone"></label>
                </div>
                <label>Village<input type="text" name="village" required></label>
                <div class="form-grid">
                    <label>Password<input type="password" name="password" minlength="8" autocomplete="new-password" required></label>
                    <label>Confirm password<input type="password" name="password_confirm" minlength="8" autocomplete="new-password" required></label>
                </div>
                <div class="form-actions">
                    <button class="primary-button" type="submit">Create worker account</button>
                    <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://unpkg.com/lucide@1.64.0/dist/umd/lucide.js"></script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
