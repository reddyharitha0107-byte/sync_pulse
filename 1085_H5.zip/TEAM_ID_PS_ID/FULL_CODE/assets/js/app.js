const appScriptUrl = (() => {
    if (document.currentScript && document.currentScript.src) {
        return new URL(document.currentScript.src);
    }
    const script = Array.from(document.querySelectorAll('script[src]')).find((item) =>
        item.src.includes('/assets/js/app.js')
    );
    return script ? new URL(script.src) : new URL('assets/js/app.js', window.location.href);
})();

function toggleSidebar(force) {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;
    const isOpen = typeof force === 'boolean' ? force : !sidebar.classList.contains('open');
    sidebar.classList.toggle('open', isOpen);
    document.body.classList.toggle('sidebar-open', isOpen);
}

function openModal(id) {
    const overlay = document.getElementById('modal-overlay');
    const modal = document.getElementById('modal-' + id);
    if (!overlay || !modal) return;

    document.querySelectorAll('.modal.active').forEach((item) => item.classList.remove('active'));
    overlay.classList.add('active');
    modal.classList.add('active');
    document.body.classList.add('modal-open');
    toggleSidebar(false);

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function closeModal() {
    document.querySelectorAll('.modal.active').forEach((item) => item.classList.remove('active'));
    const overlay = document.getElementById('modal-overlay');
    if (overlay) overlay.classList.remove('active');
    document.body.classList.remove('modal-open');
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function openProfile(id) {
    const data = window.SYNCPULSE_PROFILE;
    if (!data) return;
    const patient = (data.patients || []).find((item) => String(item.id) === String(id));
    if (!patient) return;

    const title = document.getElementById('profile-title');
    const summary = document.getElementById('profile-summary');
    const visitsBox = document.getElementById('profile-visits');
    if (title) title.textContent = patient.name;
    if (summary) {
        summary.textContent = `${patient.age} years · ${patient.gender} · ${patient.village} · ${patient.category}`;
    }

    const setValue = (fieldId, value) => {
        const field = document.getElementById(fieldId);
        if (field) field.value = value ?? '';
    };
    setValue('profile-patient-id', patient.id);
    setValue('profile-name', patient.name);
    setValue('profile-phone', patient.phone);
    setValue('profile-age', patient.age);
    setValue('profile-gender', patient.gender);
    setValue('profile-village', patient.village);
    setValue('profile-category', patient.category);
    setValue('profile-history', patient.history);
    setValue('profile-family', patient.family);

    if (visitsBox) {
        const visits = (data.visits || [])
            .filter((visit) => String(visit.patientId) === String(id))
            .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
        visitsBox.innerHTML = visits.length
            ? `<strong>Visits</strong>${visits.map((visit) => `
                <div class="profile-visit-row">
                    <span>${escapeHtml(visit.type)}</span>
                    <small>${escapeHtml(visit.date)} · ${escapeHtml(visit.time)}</small>
                    <span class="badge ${visit.status === 'Completed' ? 'green' : (visit.status === 'Overdue' || visit.status === 'Cancelled' ? 'red' : 'amber')}">${escapeHtml(visit.status)}</span>
                </div>`).join('')}`
            : '<strong>Visits</strong><p class="empty-small">No visits recorded yet.</p>';
    }

    openModal('profile');
}

function openRespond(id, patientName, condition) {
    const setText = (fieldId, value) => {
        const field = document.getElementById(fieldId);
        if (field) field.textContent = value;
    };
    setText('respond-patient', patientName || 'Patient');
    setText('respond-condition', condition || 'Condition');
    const alertId = document.getElementById('respond-alert-id');
    if (alertId) alertId.value = id || '';
    openModal('respond');
}

function openArticle(id) {
    alert('Article: ' + id);
}

function syncData() {
    const status = document.getElementById('syncStatus');
    if (!status) return;
    status.textContent = 'Refreshing…';
    window.location.reload();
}

function updateQueryParam(key, value) {
    const url = new URL(window.location.href);
    if (value) {
        url.searchParams.set(key, value);
    } else {
        url.searchParams.delete(key);
    }
    window.history.replaceState({}, '', url);
}

function searchPatients(value) {
    updateQueryParam('q', value);
    const query = value.trim().toLowerCase();
    const rows = document.querySelectorAll('.table-wrap tbody tr');
    let visible = 0;

    rows.forEach((row) => {
        const haystack = (row.dataset.search || row.textContent).toLowerCase();
        const matches = !query || haystack.includes(query);
        row.style.display = matches ? '' : 'none';
        if (matches) visible += 1;
    });

    const empty = document.getElementById('patientEmpty');
    if (empty) empty.style.display = visible === 0 ? 'flex' : 'none';
}

function filterPatients(value) {
    const url = new URL(window.location.href);
    url.searchParams.set('filter', value);
    window.location.href = url.toString();
}

function searchGuides(value) {
    updateQueryParam('q', value);
    const query = value.trim().toLowerCase();
    const cards = document.querySelectorAll('.article-grid .article-card');
    let visible = 0;

    cards.forEach((card) => {
        const haystack = (card.dataset.search || card.textContent).toLowerCase();
        const matches = !query || haystack.includes(query);
        card.style.display = matches ? '' : 'none';
        if (matches) visible += 1;
    });

    const empty = document.getElementById('guidesEmpty');
    if (empty) empty.style.display = visible === 0 ? 'flex' : 'none';
}

function changeLanguage(value) {
    const url = new URL(window.location.href);
    url.searchParams.set('lang', value);
    window.location.href = url.toString();
}

function updateOnlineStatus() {
    const status = document.getElementById('connectionStatus');
    if (!status) return;

    if (navigator.onLine) {
        status.classList.remove('offline');
        status.innerHTML = '<i data-lucide="wifi"></i><span>Online</span>';
    } else {
        status.classList.add('offline');
        status.innerHTML = '<i data-lucide="wifi-off"></i><span>Offline</span>';
    }

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);

document.addEventListener('DOMContentLoaded', () => {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    const patientSearch = document.querySelector('input[aria-label="Search patients"]');
    if (patientSearch) {
        searchPatients(patientSearch.value);
    }

    const guideSearch = document.querySelector('input[aria-label="Search health guides"]');
    if (guideSearch) {
        searchGuides(guideSearch.value);
    }

    updateOnlineStatus();
});

document.addEventListener('click', (event) => {
    const modal = event.target.closest('.modal');
    if (modal && !event.target.closest('.modal-content')) {
        closeModal();
    }

    const sidebar = document.getElementById('sidebar');
    if (
        sidebar &&
        sidebar.classList.contains('open') &&
        !sidebar.contains(event.target) &&
        !event.target.closest('.mobile-menu')
    ) {
        toggleSidebar(false);
    }
});

document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (document.querySelector('.modal.active')) {
        closeModal();
    } else {
        toggleSidebar(false);
    }
});

if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        const swUrl = new URL('../../sw.js', appScriptUrl).href;
        navigator.serviceWorker.register(swUrl).catch(() => {});
    });
}
