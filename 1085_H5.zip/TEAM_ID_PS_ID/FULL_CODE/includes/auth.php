<?php
if (session_status() === PHP_SESSION_NONE) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    session_start();
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function current_worker(): ?array
{
    $user = current_user();
    return ($user && $user['role'] === 'worker') ? $user : null;
}

function current_patient_id(): ?int
{
    $user = current_user();
    return ($user && $user['role'] === 'patient') ? (int) $user['id'] : null;
}

function current_patient(): ?array
{
    $user = current_user();
    return ($user && $user['role'] === 'patient') ? $user : null;
}

function current_admin(): ?array
{
    $user = current_user();
    return ($user && $user['role'] === 'admin') ? $user : null;
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'role' => $user['role'],
        'name' => $user['name'],
        'code' => $user['code'] ?? null,
        'email' => $user['email'] ?? null,
        'village' => $user['village'] ?? null,
    ];
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function require_worker(): void
{
    if (!current_worker()) {
        redirect_to('login.php');
    }
}

function require_patient(): void
{
    if (!current_patient_id()) {
        redirect_to('login.php');
    }
}

function require_admin(): void
{
    if (!current_admin()) {
        redirect_to('login.php');
    }
}

function redirect_to(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        exit('Session expired. Please reload the page and try again.');
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['flashes'][] = ['type' => $type, 'message' => $message];
}

function pull_flashes(): array
{
    $flashes = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $flashes;
}

function render_flashes(): void
{
    foreach (pull_flashes() as $flash) {
        $type = in_array($flash['type'], ['success', 'error', 'info'], true) ? $flash['type'] : 'info';
        echo '<div class="flash flash-' . $type . '">' . htmlspecialchars($flash['message']) . '</div>';
    }
}
