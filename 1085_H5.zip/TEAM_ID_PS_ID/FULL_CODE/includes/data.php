<?php
require_once __DIR__ . '/db.php';

/**
 * Load patients, visits, and alerts from MySQL.
 *
 * $scope can be:
 *  - 'auto' (default): current worker's community, or everything for other users
 *  - 'all': everything (super admin)
 *  - an integer worker id
 */
function getSeedData($scope = 'auto'): array
{
    $workerId = null;
    if ($scope === 'all') {
        $workerId = null;
    } elseif (is_numeric($scope)) {
        $workerId = (int) $scope;
    } elseif (function_exists('current_worker')) {
        $worker = current_worker();
        if ($worker) {
            $workerId = (int) $worker['id'];
        }
    }

    $patientSql = 'SELECT p.id, p.name, p.email, p.phone, p.age, p.gender, p.village,
                          p.category, p.history, p.family, p.assigned_worker_id,
                          p.created_by_worker_id, p.status, p.created_at,
                          w.name AS worker_name
                   FROM patients p
                   LEFT JOIN workers w ON w.id = p.assigned_worker_id
                   WHERE p.status = "active"';
    $patientParams = [];
    if ($workerId !== null) {
        $patientSql .= ' AND (p.assigned_worker_id = :worker_assigned OR p.created_by_worker_id = :worker_created)';
        $patientParams = [':worker_assigned' => $workerId, ':worker_created' => $workerId];
    }
    $patientSql .= ' ORDER BY p.name';

    $patientStatement = db()->prepare($patientSql);
    $patientStatement->execute($patientParams);
    $patients = $patientStatement->fetchAll();

    $patientsById = [];
    foreach ($patients as $patient) {
        $patientsById[(int) $patient['id']] = $patient;
    }

    $visitSql = 'SELECT v.*, DATE_FORMAT(v.visit_time, "%h:%i %p") AS time
                 FROM visits v
                 JOIN patients p ON p.id = v.patient_id
                 WHERE p.status = "active"';
    $visitParams = [];
    if ($workerId !== null) {
        $visitSql .= ' AND v.worker_id = :worker_id';
        $visitParams[':worker_id'] = $workerId;
    }
    $visitSql .= ' ORDER BY v.visit_date ASC, v.visit_time ASC';

    $visitStatement = db()->prepare($visitSql);
    $visitStatement->execute($visitParams);
    $visits = [];
    $today = date('Y-m-d');
    foreach ($visitStatement->fetchAll() as $visit) {
        $status = $visit['status'];
        if ($status === 'Upcoming' && $visit['visit_date'] < $today) {
            $status = 'Overdue';
        }
        $visits[] = [
            'id' => (int) $visit['id'],
            'patientId' => (int) $visit['patient_id'],
            'workerId' => $visit['worker_id'] !== null ? (int) $visit['worker_id'] : null,
            'date' => $visit['visit_date'],
            'time' => $visit['time'],
            'type' => $visit['type'],
            'status' => $status,
            'notes' => $visit['notes'] ?? '',
        ];
    }

    $alertSql = 'SELECT a.*, p.name AS patient_name, p.village
                 FROM alerts a
                 JOIN patients p ON p.id = a.patient_id
                 WHERE p.status = "active"';
    $alertParams = [];
    if ($workerId !== null) {
        $alertSql .= ' AND a.worker_id = :worker_id';
        $alertParams[':worker_id'] = $workerId;
    }
    $alertSql .= ' ORDER BY a.resolved ASC, a.created_at DESC';

    $alertStatement = db()->prepare($alertSql);
    $alertStatement->execute($alertParams);
    $alerts = [];
    foreach ($alertStatement->fetchAll() as $alert) {
        $alerts[] = [
            'id' => (int) $alert['id'],
            'patientId' => (int) $alert['patient_id'],
            'condition' => $alert['condition_text'],
            'urgency' => $alert['urgency'],
            'resolved' => (bool) $alert['resolved'],
            'created' => $alert['created_at'],
        ];
    }

    return [
        'patients' => $patients,
        'patientsById' => $patientsById,
        'visits' => $visits,
        'alerts' => $alerts,
    ];
}

function get_patient_by_id(int $patientId): ?array
{
    $statement = db()->prepare(
        'SELECT p.id, p.name, p.email, p.phone, p.age, p.gender, p.village,
                p.category, p.history, p.family, p.assigned_worker_id,
                p.created_by_worker_id, p.status, p.created_at,
                w.name AS worker_name, w.worker_code
         FROM patients p
         LEFT JOIN workers w ON w.id = p.assigned_worker_id
         WHERE p.id = ? AND p.status = "active"'
    );
    $statement->execute([$patientId]);
    $patient = $statement->fetch();
    return $patient ?: null;
}

function get_active_workers(): array
{
    return db()->query(
        'SELECT id, worker_code, name, village, phone, email
         FROM workers WHERE status = "active" ORDER BY name'
    )->fetchAll();
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    if (count($parts) === 0) {
        return '';
    }
    if (count($parts) === 1) {
        return strtoupper(substr($parts[0], 0, 2));
    }
    return strtoupper(substr($parts[0], 0, 1) . substr($parts[1], 0, 1));
}

function dateLabel(string $date): string
{
    $d = new DateTime($date . ' 12:00:00');
    return $d->format('d M');
}

function getArticles(): array
{
    return [
        [
            'id' => 'first',
            'title' => 'First aid essentials',
            'category' => 'First aid',
            'time' => '4 min read',
            'body' => 'For minor cuts, wash your hands, rinse the wound with clean water, apply gentle pressure with a clean cloth, and cover with a clean dressing. Seek care for deep wounds, animal bites, infection, or bleeding that does not stop.',
            'hi' => 'मामूली कट को साफ पानी से धोएं, साफ कपड़े से हल्का दबाव दें और साफ पट्टी लगाएं। गहरे घाव या लगातार खून बहने पर चिकित्सा सहायता लें।',
            'te' => 'చిన్న గాయాన్ని శుభ్రమైన నీటితో కడిగి, శుభ్రమైన గుడ్డతో మెల్లగా ఒత్తిడి చేసి కట్టు కట్టండి. లోతైన గాయం లేదా ఆగని రక్తస్రావానికి వైద్య సహాయం పొందండి.',
        ],
        [
            'id' => 'maternal',
            'title' => 'A healthy pregnancy',
            'category' => 'Maternal care',
            'time' => '5 min read',
            'body' => 'Attend scheduled antenatal visits. Eat varied nutritious meals and use supplements only as prescribed. Severe headache, blurred vision, bleeding, fever, or reduced fetal movement need urgent medical assessment.',
            'hi' => 'नियमित प्रसवपूर्व जांच कराएं और पौष्टिक भोजन खाएं। तेज सिरदर्द, धुंधली दृष्टि, रक्तस्राव या बुखार होने पर तुरंत चिकित्सकीय सहायता लें।',
            'te' => 'క్రమం తప్పకుండా గర్భధారణ పరీక్షలు చేయించుకోండి. పోషకాహారం తీసుకోండి. తీవ్రమైన తలనొప్పి, చూపు మందగించడం, రక్తస్రావం లేదా జ్వరం ఉంటే వెంటనే వైద్య సహాయం పొందండి.',
        ],
        [
            'id' => 'fever',
            'title' => 'Fever: when to seek care',
            'category' => 'Common conditions',
            'time' => '3 min read',
            'body' => 'Rest, drink safe fluids, and monitor symptoms. Fever in a baby under 3 months, difficulty breathing, confusion, stiff neck, or signs of dehydration require immediate medical assessment. Do not take antibiotics without a clinician’s prescription.',
            'hi' => 'आराम करें, सुरक्षित पानी पिएं और लक्षणों पर ध्यान दें। 3 महीने से छोटे शिशु में बुखार, सांस लेने में कठिनाई या भ्रम होने पर तुरंत डॉक्टर से संपर्क करें।',
            'te' => 'విశ్రాంతి తీసుకోండి, సురక్షితమైన ద్రవాలు తాగండి. 3 నెలల లోపు శిశువులో జ్వరం, శ్వాస ఇబ్బంది లేదా గందరగోళం ఉంటే వెంటనే వైద్య సహాయం పొందండి.',
        ],
        [
            'id' => 'hydration',
            'title' => 'Safe water & dehydration',
            'category' => 'Prevention',
            'time' => '3 min read',
            'body' => 'Use safe drinking water and wash hands with soap. For diarrhoea, use packaged ORS mixed with exactly the amount of safe water on the packet. Seek urgent care for inability to drink, persistent vomiting, blood in stools, or unusual sleepiness.',
            'hi' => 'सुरक्षित पानी पिएं और साबुन से हाथ धोएं। दस्त में पैकेट पर दिए निर्देश के अनुसार ओआरएस बनाएं। पानी न पी पाने, लगातार उल्टी या मल में खून होने पर तुरंत सहायता लें।',
            'te' => 'సురక్షితమైన నీరు తాగండి, సబ్బుతో చేతులు కడుక్కోండి. విరేచనాలకు ప్యాకెట్ సూచనల ప్రకారం ఓఆర్ఎస్ కలపండి. తాగలేకపోవడం లేదా మలంలో రక్తం ఉంటే వెంటనే సహాయం పొందండి.',
        ],
    ];
}
