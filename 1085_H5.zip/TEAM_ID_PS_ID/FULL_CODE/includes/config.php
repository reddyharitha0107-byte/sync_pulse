<?php

/**
 * Load KEY=value pairs from FULL_CODE/.env without overriding real
 * environment variables. The file is optional and never committed.
 */
function syncpulse_load_env_file(string $path): void
{
    if (!is_readable($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return;
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        $parts = explode('=', $line, 2);
        if (count($parts) !== 2) {
            continue;
        }

        $key = trim($parts[0]);
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $key) || getenv($key) !== false) {
            continue;
        }

        $value = trim($parts[1]);
        if (strlen($value) >= 2) {
            $first = $value[0];
            $last = $value[strlen($value) - 1];
            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $value = substr($value, 1, -1);
            }
        }

        putenv($key . '=' . $value);
        $_ENV[$key] = $value;
    }
}

syncpulse_load_env_file(dirname(__DIR__) . '/.env');

function db_config(): array
{
    return [
        'host' => getenv('SYNCPULSE_DB_HOST') ?: '127.0.0.1',
        'port' => getenv('SYNCPULSE_DB_PORT') ?: '3306',
        'name' => getenv('SYNCPULSE_DB_NAME') ?: 'syncpulse',
        'user' => getenv('SYNCPULSE_DB_USER') ?: 'root',
        'pass' => getenv('SYNCPULSE_DB_PASS') ?: '',
    ];
}
