================================================================================
SYNCPULSE PHP - CONNECTED COMMUNITY CARE
Project README / File & Function Reference
================================================================================

SyncPulse is a small community-healthcare web application written in plain PHP
(no framework) backed by MySQL. It provides three separate portals:

  1. Super Admin   - registers and manages ASHA worker accounts, and can view
                     every patient, visit, and alert in the system.
  2. ASHA Worker   - manages their own community: adds/edits patients, schedules
                     visits, completes or cancels visits, creates alerts, and
                     resolves them.
  3. Patient       - self-registers, signs in, edits their health profile, books
                     a home visit, cancels an upcoming visit, and requests help.

The front end is server-rendered HTML with a shared CSS file, a shared JavaScript
file, and Google's Lucide icon library. A service worker plus web manifest make
the app installable and partially usable offline (read-only cached pages).


--------------------------------------------------------------------------------
1. REQUIREMENTS
--------------------------------------------------------------------------------

  - PHP 8.1 or newer (uses typed properties/returns, null-safe patterns, etc.)
  - MySQL 5.7+ or 8.0+ (uses InnoDB, utf8mb4, ENUM, and foreign keys)
  - A web server with PHP support, such as Laragon / Apache / Nginx
  - PHP PDO MySQL extension enabled (pdo_mysql)
  - Internet access on first load for Google Fonts and the Lucide icon CDN
    (the app also works without these; icons/fonts simply fall back gracefully)


--------------------------------------------------------------------------------
2. QUICK START (LARAGON)
--------------------------------------------------------------------------------

  1. Start Apache and MySQL from the Laragon control panel.

  2. Open a terminal in the project root and run:

         php database/setup.php

     This creates the "syncpulse" database, all tables, and demo data. The
     script is idempotent: it only seeds tables that are empty, so re-running it
     will not wipe existing records.

     You can alternatively open database/setup.php in the browser
     (http://localhost/syncpulse_php/database/setup.php).

  3. Open the application:

         http://localhost/syncpulse_php/index.php

  4. Sign in with one of the demo accounts listed below.

Database credentials are read from includes/config.php. They default to Laragon's
"root" user with an empty password. You can override them with environment
variables:

    SYNCPULSE_DB_HOST   (default 127.0.0.1)
    SYNCPULSE_DB_PORT   (default 3306)
    SYNCPULSE_DB_NAME   (default syncpulse)
    SYNCPULSE_DB_USER   (default root)
    SYNCPULSE_DB_PASS   (default empty)


--------------------------------------------------------------------------------
3. DEMO ACCOUNTS
--------------------------------------------------------------------------------

  Role          Login                      Password
  ------------  -------------------------  ------------
  Super Admin   admin@syncpulse.local      Admin@123
  ASHA Worker   DEMO-ASHA-001              Worker@123
  ASHA Worker   DEMO-ASHA-002              Worker@123
  Patient       lakshmi.devi@example.com   Patient@123

  Other seeded patients (all use Patient@123):
    ramesh.kumar@example.com, anjali.yadav@example.com,
    sunita.patel@example.com, mohan.lal@example.com,
    priya.sharma@example.com, aarav.singh@example.com,
    kamala.bai@example.com

  Demo data is fictional. Replace/remove these accounts and change the seeded
  passwords before any real deployment.


--------------------------------------------------------------------------------
4. DIRECTORY TREE
--------------------------------------------------------------------------------

  syncpulse_php/
  |-- index.php                     Public landing page (portal chooser)
  |-- README.php                    Browser-rendered setup/help page
  |-- readme.txt                    This file
  |-- sw.js                         Service worker (offline/PWA caching)
  |
  |-- admin/
  |   |-- index.php                 Super admin dashboard (all sections)
  |   |-- login.php                 Super admin login
  |   |-- logout.php                Ends admin session
  |   +-- components/
  |       |-- sidebar.php           Admin navigation sidebar
  |       +-- topbar.php            Admin top bar / breadcrumb
  |
  |-- worker/
  |   |-- index.php                 Worker workspace controller + layout
  |   |-- login.php                 ASHA worker login (by Worker ID)
  |   |-- logout.php                Ends worker session
  |   |-- components/
  |   |   |-- sidebar.php           Worker navigation sidebar
  |   |   |-- topbar.php            Worker top bar (status, refresh, language)
  |   |   |-- modals.php            All worker dialogs/forms
  |   |   +-- offline-notice.php    Offline banner + storage warning
  |   +-- pages/
  |       |-- overview.php          Worker dashboard / today's visits
  |       |-- patients.php          Patient list with search and filter
  |       |-- alerts.php            Visit list + emergency alert queue
  |       |-- metrics.php           Visit statistics and weekly chart
  |       +-- knowledge.php         Offline health guides (multi-language)
  |
  |-- patient/
  |   |-- index.php                 Patient portal controller + layout
  |   |-- login.php                 Patient login (by email)
  |   |-- register.php              Public patient self-registration
  |   |-- logout.php                Ends patient session
  |   |-- components/
  |   |   |-- header.php            Patient top bar
  |   |   |-- modals.php            Help / book visit / edit profile dialogs
  |   |   +-- offline-notice.php    Patient offline banner
  |   +-- pages/
  |       +-- portal.php            Patient dashboard content
  |
  |-- includes/
  |   |-- config.php                Database configuration helper
  |   |-- db.php                    PDO connection factories
  |   |-- auth.php                  Sessions, roles, CSRF, flash messages
  |   +-- data.php                  Query helpers and static content
  |
  |-- database/
  |   |-- schema.sql                Table definitions
  |   +-- setup.php                 Creates DB, tables, and demo seed data
  |
  +-- assets/
      |-- css/style.css             Entire application stylesheet
      |-- js/app.js                 Shared client-side JavaScript
      |-- manifest.webmanifest      PWA manifest
      |-- icon.svg                  Scalable app icon
      |-- icon-192.png              PWA icon 192x192
      |-- icon-512.png              PWA icon 512x512
      +-- favicon.ico               Browser tab icon


================================================================================
5. FILE-BY-FILE REFERENCE
================================================================================

--------------------------------------------------------------------------------
ROOT
--------------------------------------------------------------------------------

index.php
---------
The public landing page. It starts the session (via includes/auth.php) and reads
the current session to decide where each portal link points:
  - If an admin/worker/patient is already signed in, the link becomes
    "Continue as ..." and points at that portal's dashboard.
  - Otherwise it points at the matching login page.
It also advertises "Offline ready" and "MySQL powered", shows demo credentials,
and links to patient self-registration. Purely presentational; no writes.

README.php
----------
A browser-friendly HTML setup guide (database setup, demo accounts, portal links,
feature summary, project structure, and notes). It is not used by the app logic;
it exists to help a human set the project up. It contains a .php extension only so
it can be served by PHP-enabled hosts, and it opens with an empty PHP block.

readme.txt (this file)
----------------------
Plain-text documentation covering every file and its purpose.

sw.js (Service Worker)
----------------------
Implements offline/PWA support for the landing page and static assets.

  CACHE            Cache name "syncpulse-shell-v5". Bump this string to force
                   clients to fetch a fresh shell after a deploy.
  INDEX_URL        Absolute URL of index.php (used as the navigation fallback).
  PRECACHE         List of shell assets cached at install time (index.php, CSS,
                   JS, manifest, icons).

  install event    Pre-caches PRECACHE, then calls skipWaiting() so the new worker
                   activates immediately.
  activate event   Deletes older "syncpulse-shell-*" caches and claims open clients.
  fetch event      Handles GET requests only, same origin only, skipping /api/ and
                   /.netlify/ paths. Network-first for page navigations (5s
                   timeout) with cache fallback, and cache-first for static
                   assets (js/css/fonts/images/manifest). If no cache exists for
                   a navigation it returns a short "open online once" message.
  message event    Handles a CACHE_ASSETS message: validates/normalises a list of
                   URLs, restricts them to app assets, caches any missing ones,
                   then reports { ready: true|false } back through the port.

--------------------------------------------------------------------------------
ADMIN PORTAL (admin/)
--------------------------------------------------------------------------------

admin/index.php
---------------
Controller and single-page dashboard for the Super Admin. It requires an admin
session (require_admin()), then handles POST actions before rendering views.

  POST actions (all CSRF-protected):
    add_worker      Validates worker_code (3-50 chars: A-Z, 0-9, dash), name,
                    email, village, and password (min 8 chars, must match
                    confirmation). Inserts a new active worker into the workers
                    table created by this admin. Duplicate worker code/email is
                    caught (SQLSTATE 23000) and reported via flash message.
    toggle_worker   Flips a worker between "active" and "inactive". Inactive
                    workers cannot sign in.

  Views (selected by ?view=, whitelisted):
    Overview        Stat cards (worker count, patient count, today's visits,
                    open alerts), a recent-workers table, and a list of open
                    alerts across all communities.
    Workers         Full worker table with patient counts and an
                    activate/deactivate button per worker.
    Patients        Every active patient with contact, village, care focus,
                    assigned worker, and registration date.
    Visits          Every visit (scheduled, completed, overdue) across all
                    communities.
    Alerts          Every patient/worker alert with urgency, worker, date, and
                    resolved/open status.

  Data is loaded via getSeedData('all') plus a dedicated workers query that
  includes the creator's name and per-worker patient counts. It also includes the
  "Register ASHA worker" modal. Redirects after every POST (POST/Redirect/GET).

admin/login.php
---------------
Admin sign-in. If already signed in, redirects to the dashboard. On POST it
verifies CSRF, looks up the admin by lowercase email, and verifies the password
with password_verify(). On success it calls login_user() with role "admin" and
redirects to the dashboard. Invalid credentials show a generic error.

admin/logout.php
----------------
Calls logout_user() to clear and destroy the session, then redirects to login.php.

admin/components/sidebar.php
----------------------------
Renders the admin sidebar: brand button, the five navigation modules (Overview,
Workers, Patients, Visits, Alerts) with an open-alert badge, a "MySQL connected"
status card, quick links to the worker and patient logins, and the admin's
identity/sign-out button. It expects $view to be set by index.php.

admin/components/topbar.php
---------------------------
Renders the admin top bar: mobile menu toggle, breadcrumb ("Super admin >
$view"), a MySQL indicator, the admin name/avatar, and a sign-out avatar button.

--------------------------------------------------------------------------------
WORKER PORTAL (worker/)
--------------------------------------------------------------------------------

worker/index.php
----------------
Controller and layout for the ASHA worker workspace. It requires a worker session
(require_worker()), then handles POST actions, resolves the requested view, and
includes the matching page.

  $ownsPatient()   Local closure used for authorization. Returns true only when the
                   patient is active AND was either assigned to this worker or
                   created by this worker.

  POST actions (all CSRF-protected):
    add_patient     Validates name/email/phone/age(1-120)/gender/village/category,
                    then inserts a patient assigned to and created by this worker.
                    Duplicate email is caught and reported.
    schedule_visit  Creates an "Upcoming" visit for one of the worker's patients.
                    Requires a date, time, and visit type.
    create_alert    Creates an alert for one of the worker's patients with
                    urgency High, Medium, or Help request.
    resolve_alert   Marks an alert resolved (sets resolved=1, resolved_by,
                    resolved_at) only if it belongs to this worker and is open.
    complete_visit  Sets a visit to "Completed" if it belongs to this worker and
                    is not already cancelled.
    cancel_visit    Sets an "Upcoming" visit to "Cancelled" (worker-owned only).
    update_patient  Updates name, phone, age, gender, village, category, history,
                    and family for a worker-owned patient.

  View map (?view=, whitelisted):
    Overview  -> pages/overview.php
    Search    -> pages/knowledge.php
    Patients  -> pages/patients.php
    Emergency -> pages/alerts.php   (alert queue)
    Alerts    -> pages/alerts.php   (visit list, filter by status)
    Cure      -> pages/knowledge.php
    Metrics   -> pages/metrics.php

  The layout includes the sidebar, top bar, offline notice, flash messages, the
  selected page, all modals, and exposes window.SYNCPULSE_PROFILE as JSON
  (patients, visits, categories, genders) for the client-side profile modal.

worker/login.php
----------------
Worker sign-in by Worker ID. Uppercases/trims the code, looks up the worker, and
only accepts active workers whose password verifies. Inactive accounts get a
specific "contact the super admin" message. On success stores role "worker" plus
code, email, and village in the session.

worker/logout.php
-----------------
Calls logout_user() and redirects to login.php.

worker/components/sidebar.php
-----------------------------
Worker navigation: Overview, Search, Patients, Emergency, Alerts, Cure, Metrics;
an open-alert count badge on Emergency; a language-independent "Database
connected" status card; a link to the patient portal; Help & support (opens the
support modal); and the worker identity/sign-out button.

worker/components/topbar.php
----------------------------
Worker top bar: mobile menu, breadcrumb, live online/offline connection indicator
(element id "connectionStatus"), a "Refresh data" button (syncData), a language
button (opens language modal), an alerts shortcut, and a sign-out avatar.

worker/components/modals.php
----------------------------
All worker dialogs, each a plain HTML form posting back to worker/index.php:

  modal-language   Display-only language selector (English/Hindi/Telugu labels).
  modal-add        "Add patient" form (action=add_patient) with all demographic
                   and care fields; village defaults to the worker's village.
  modal-emergency  "Create alert" form (action=create_alert) with patient select,
                   condition, and urgency.
  modal-schedule   "Schedule visit" form (action=schedule_visit) with patient,
                   date (defaults to today), time (defaults 09:00), type, notes.
  modal-respond    "Review alert" form (action=resolve_alert); its patient name,
                   condition, and alert id are filled by openRespond() in JS.
  modal-profile    "Patient profile" form (action=update_patient) pre-filled by
                   openProfile() from window.SYNCPULSE_PROFILE, including a
                   rendered list of the patient's visits.
  modal-support    Help & support information with the 112 emergency notice.

worker/components/offline-notice.php
------------------------------------
Static informational banner explaining offline capabilities and a hidden
"#storageError" warning shown when browser storage is unavailable.

worker/pages/overview.php
-------------------------
Worker dashboard. Loads the worker's scoped data (getSeedData()), computes open
alerts, completed/pending/today's visits, and renders:
  - Greeting header with a date label.
  - Care banner showing how many visits are scheduled today.
  - Four clickable stat cards (patients, completed, pending, active emergencies)
    that link to the relevant section.
  - "Today's visits" panel with Today/Upcoming/Completed tabs (?filter=), rows
    showing patient, visit type, village/date, time, and status; clicking a row
    opens the patient profile.
  - "Needs attention" panel summarising the most urgent open alert with a
    "Review alert" button (openRespond).

worker/pages/patients.php
-------------------------
Patient directory. Shows all of the worker's patients in a table with avatar,
age/gender, village, care-focus badge, last completed visit, and a "View profile"
button. Includes a live search box (searchPatients) and a category filter
(?filter=). Shows "No patients found" when a search returns nothing.

worker/pages/alerts.php
-----------------------
Dual-purpose page driven by $view:

  view=Alerts     A visit list with tabs Today / Upcoming / Overdue / Completed
                  (?filter=). Each upcoming/overdue visit has inline "complete"
                  (check) and "cancel" (x) buttons that POST to index.php. Clicking
                  a patient opens their profile. A "Schedule visit" button opens
                  the schedule modal.
  view=Emergency  The alert queue: a red emergency banner with a "Call 112" link,
                  an open-request count, a "Create demo alert" button, alert cards
                  (urgency, patient, condition, village, "Review alert"), an empty
                  state, and a "Resolved requests" panel listing closed alerts.

worker/pages/metrics.php
------------------------
Read-only analytics: four stat cards, a seven-day bar chart (scheduled vs.
completed visits per day, based on today and the previous six days), and a
circular progress ring showing the percentage of visits completed. All figures
are computed from the worker's scoped data.

worker/pages/knowledge.php
--------------------------
Offline health-guide library. Renders four article cards from getArticles()
(first aid, healthy pregnancy, fever, safe water). Provides a live search box
(searchGuides), a language selector (English / Hindi / Telugu, ?lang=) that swaps
the preview text, an empty state, and a medical disclaimer. The Hindi and Telugu
text lives in includes/data.php.

--------------------------------------------------------------------------------
PATIENT PORTAL (patient/)
--------------------------------------------------------------------------------

patient/index.php
-----------------
Controller and layout for the patient portal. Requires a patient session
(require_patient()) and the patient's database record. Handles POST actions:

    update_profile  Validates required fields and enum values, updates the
                    patient's own record, refreshes name/village in the session,
                    and flashes a success message.
    request_help    Inserts an alert using the patient's assigned worker (or the
                    first active worker as a fallback) with the given condition
                    and urgency.
    book_visit      Inserts an "Upcoming" visit for the patient with the assigned
                    worker (fallback to first active worker).
    cancel_visit    Cancels one of the patient's own "Upcoming" visits.

  After POST handling it loads the patient via get_patient_by_id(), loads all
  data, filters it down to this patient's visits and alerts, then renders the
  header, offline notice, flashes, portal page, and modals. If the patient record
  no longer exists it logs the user out.

patient/login.php
-----------------
Patient sign-in by email. Only active patients with a non-null password_hash are
eligible. Verifies with password_verify(), then stores role "patient", name,
email, and village in the session.

patient/register.php
--------------------
Public self-registration. Collects name, age, gender, village, email, phone,
category, optional history/family, and a password (min 8 chars, confirmed). On
success it auto-assigns an active worker in the same village (case-sensitive
match), falling back to the first active worker, creates the patient, signs them
in, and redirects to the portal. Duplicate email is reported gracefully.

patient/logout.php
------------------
Calls logout_user() and redirects to login.php.

patient/components/header.php
-----------------------------
Patient top bar with brand, live online/offline indicator, the patient's
name/avatar, and a Sign out button.

patient/components/modals.php
-----------------------------
Three patient dialogs posting to patient/index.php:
  modal-emergency   Request help (action=request_help): condition + urgency.
  modal-schedule    Book visit (action=book_visit): date, time, visit type.
  modal-profile     Edit health profile (action=update_profile): all profile
                    fields pre-filled from the patient record.

patient/components/offline-notice.php
-------------------------------------
Static banner explaining that saved health info is readable offline and that no
emergency service is contacted by the demo.

patient/pages/portal.php
------------------------
Patient dashboard content:
  - Greeting and the assigned worker's name.
  - A profile banner with age, gender, village, category, phone, and worker.
  - Action buttons: Request help, Book visit, Edit profile.
  - "My health profile" panel (medical history and family details).
  - "My visits" panel with status badges and a cancel button on upcoming visits.
  - "My help requests" panel listing each alert's condition, date, urgency, and
    resolved/open state.

--------------------------------------------------------------------------------
SHARED INCLUDES (includes/)
--------------------------------------------------------------------------------

includes/config.php
-------------------
Defines db_config(): array, which returns host, port, name, user, and pass from
environment variables (with Laragon-friendly defaults). This is the single place
to change database credentials.

includes/db.php
---------------
Defines two PDO factories, both using utf8mb4, exception error mode, associative
fetches, and real (non-emulated) prepared statements:
  db_server()  Connects to the MySQL server WITHOUT selecting a database. Used by
               setup.php to CREATE DATABASE. Cached in a static variable.
  db()         Connects to the configured database. Used by all app queries.
               Cached in a static variable.

includes/auth.php
-----------------
Session and security helpers (starts the session on include):

  current_user()          Returns the session user array or null.
  current_worker()        Returns the user only if role is "worker".
  current_patient_id()    Returns the user id only if role is "patient".
  current_patient()       Returns the user array only if role is "patient".
  current_admin()         Returns the user only if role is "admin".
  login_user($user)       Regenerates the session id, then stores id, role, name,
                          code, email, and village in $_SESSION['user'].
  logout_user()           Clears $_SESSION, expires the session cookie, and
                          destroys the session.
  require_worker()        Redirects to login.php unless a worker is signed in.
  require_patient()       Redirects to login.php unless a patient is signed in.
  require_admin()         Redirects to login.php unless an admin is signed in.
  redirect_to($path)      Sends a Location header and exits.
  csrf_token()            Lazily creates/stores a 32-byte hex CSRF token.
  csrf_field()            Returns a hidden CSRF input for forms.
  verify_csrf()           Compares the POST token with hash_equals(); on failure
                          returns HTTP 419 and exits.
  flash($type, $message)  Queues a one-time message (success/error/info).
  pull_flashes()          Returns and clears all queued messages.
  render_flashes()        Prints queued messages as styled divs (type-validated).

includes/data.php
-----------------
Database query helpers plus static content used by the portals:

  getSeedData($scope)     Loads patients (with worker name), visits, and alerts.
                          $scope controls filtering:
                            'auto'    -> the current worker's community, or all
                                         data for admins/patients.
                            'all'     -> everything (super admin).
                            <int>     -> a specific worker id.
                          Also:
                            - Overrides status "Upcoming" with "Overdue" when the
                              visit date is before today.
                            - Adds a formatted 12-hour "time" field per visit.
                            - Returns patients, patientsById (keyed by id),
                              visits, and alerts arrays.
  get_patient_by_id(id)   Returns one active patient joined with their worker
                          name/code, or null.
  get_active_workers()    Returns id, worker_code, name, village, phone, email
                          for all active workers, ordered by name.
  initials($name)         Returns 1-2 uppercase initials for avatars.
  dateLabel($date)        Formats a date as "d M" (e.g. "26 Oct").
  getArticles()           Returns the four static health guides (first aid,
                          maternal care, fever, safe water), each with an id,
                          title, category, read time, English body, and Hindi and
                          Telugu translations.

--------------------------------------------------------------------------------
DATABASE (database/)
--------------------------------------------------------------------------------

database/schema.sql
-------------------
Creates five InnoDB/utf8mb4 tables. All statements use IF NOT EXISTS.

  admins
    id, name, email (unique), password_hash, created_at.
    The super-admin accounts.

  workers
    id, worker_code (unique), name, email (unique), phone, village,
    password_hash, status (active/inactive), created_by (FK -> admins),
    created_at.
    ASHA worker accounts. created_by is set to the admin who registered them.

  patients
    id, name, email (unique), phone, password_hash (nullable, for worker-added
    patients who cannot log in), age, gender (Female/Male/Other), village,
    category (General care/Maternal care/Child health/Chronic care), history,
    family, assigned_worker_id (FK -> workers), created_by_worker_id
    (FK -> workers), status (active/inactive), created_at.
    Indexed on assigned_worker_id and village.

  visits
    id, patient_id (FK -> patients, cascade delete), worker_id (FK -> workers),
    visit_date, visit_time, type, status (Upcoming/Completed/Cancelled), notes,
    created_at.
    Indexed on date, worker, and patient. "Overdue" is computed at read time and
    is NOT stored.

  alerts
    id, patient_id (FK -> patients, cascade delete), worker_id (FK -> workers),
    condition_text, urgency (High/Medium/Help request), resolved (0/1),
    resolved_by (FK -> workers), resolved_at, created_at.
    Indexed on worker and resolved.

  Foreign-key behavior: deleting a patient cascades to their visits and alerts;
  deleting a worker/admin sets the referencing foreign keys to NULL (records are
  preserved).

database/setup.php
------------------
CLI/browser bootstrap script. It:
  1. Reads config, connects to the server, and creates the database if missing.
  2. Executes schema.sql to create tables.
  3. Counts admins/workers/patients and seeds only the tables that are empty:
       - Default admin: admin@syncpulse.local / Admin@123.
       - Two workers: DEMO-ASHA-001 (Sunita Kumari, Rampur) and DEMO-ASHA-002
         (Meena Rao, Chandpur), both Worker@123.
       - Eight patients assigned by village, all Patient@123.
       - Nine visits (today, past, and upcoming) with mixed statuses.
       - Three alerts (one high, one medium, one help request; one resolved).
  Each step prints a message (plain text in CLI, HTML in the browser). Any error
  is caught, reported, and exits with status 1.

--------------------------------------------------------------------------------
ASSETS (assets/)
--------------------------------------------------------------------------------

assets/css/style.css
--------------------
The complete application stylesheet: design tokens/colors, landing page,
authentication cards, app shell, sidebars, top bars, stat cards, panels, tables,
visit lists, alerts/emergency styles, charts, progress ring, modals, forms,
badges, flash messages, responsive/mobile rules, and patient-portal styles.

assets/js/app.js
----------------
Shared client-side behaviour used by every page:

  appScriptUrl            Resolves the absolute URL of app.js so the service
                          worker path can be computed reliably.
  toggleSidebar(force)    Opens/closes the mobile sidebar and body class.
  openModal(id)           Shows the overlay and the #modal-<id> dialog, closes any
                          other open modal, stops sidebar, and re-renders icons.
  closeModal()            Hides all modals and the overlay.
  escapeHtml(value)       Escapes HTML for safely building injected markup.
  openProfile(id)         Reads window.SYNCPULSE_PROFILE, finds the patient, fills
                          the worker's profile form fields and visit history, and
                          opens the profile modal.
  openRespond(id, ...)    Fills the "Review alert" modal with the patient name,
                          condition, and alert id, then opens it.
  openArticle(id)         Placeholder (currently shows an alert with the id).
  syncData()              Sets "Refreshing..." and reloads the page.
  updateQueryParam(k, v)  Updates a URL query parameter without a reload.
  searchPatients(value)   Live-filters patient table rows via data-search, updates
                          the ?q= parameter, and toggles the empty state.
  filterPatients(value)   Navigates to the same page with ?filter=<value>.
  searchGuides(value)     Live-filters knowledge article cards and updates ?q=.
  changeLanguage(value)   Navigates with ?lang=<value>.
  updateOnlineStatus()    Swaps the connection indicator between Online/Offline
                          using navigator.onLine; wired to online/offline events.
  DOMContentLoaded        Renders Lucide icons, re-applies any existing searches,
                          and sets the initial online status.
  click / keydown         Click-outside closes modals/sidebar; Escape closes the
                          active modal or the sidebar.
  serviceWorker           On window load, registers ../../sw.js relative to
                          app.js (ignores registration errors).

assets/manifest.webmanifest
---------------------------
PWA metadata: name, short name, start_url (../index.php), scope, standalone
display, background/theme colors, and 192px/512px/SVG icons.

assets/icon.svg, icon-192.png, icon-512.png, favicon.ico
--------------------------------------------------------
Application icons referenced by the HTML pages, the manifest, and the service
worker pre-cache list.


================================================================================
6. REQUEST / DATA FLOW SUMMARY
================================================================================

  Browser -> index.php (choose portal)
          -> <role>/login.php (CSRF check, password_verify, login_user)
          -> <role>/index.php (require_<role>(), POST actions, PRG redirect)
          -> includes/data.php (scoped reads) -> includes/db.php -> MySQL
          -> PHP renders HTML -> assets/css + assets/js enhance the page
          -> sw.js serves cached shell/assets when offline

  Authorization model:
    - Admin: full read access to all data.
    - Worker: only patients they are assigned to or created, and only those
      patients' visits/alerts (enforced in SQL and via $ownsPatient()).
    - Patient: only their own record, visits, and alerts (enforced in SQL).


================================================================================
7. SECURITY NOTES
================================================================================

  - Passwords are hashed with PHP password_hash() and checked with
    password_verify(). Never plain-text.
  - All database writes use prepared statements (PDO, emulation disabled).
  - Every POST form includes a CSRF token verified with hash_equals().
  - Sessions are regenerated on login; logout expires the cookie and destroys
    the session.
  - Output is escaped with htmlspecialchars() before rendering user content.
  - Role guards (require_admin/worker/patient) protect every private page.
  - Ownership checks prevent a worker from editing another worker's patients and
    a patient from cancelling another patient's visit.
  - Still required before production: HTTPS, secure session cookie settings,
    unique/strong credentials, removal of demo accounts, and rate limiting.


================================================================================
8. OFFLINE / PWA BEHAVIOUR
================================================================================

  - Offline support requires one successful ONLINE visit first (to install the
    service worker and cache assets).
  - The service worker and manifest require an HTTP(S) server; opening files
    directly via file:// will not enable them.
  - Cached pages are read-only shells: you can view them offline, but form
    submissions (help requests, bookings, edits) need a connection because they
    write to MySQL.
  - The offline notices in both portals explain that no emergency service is
    contacted; the demo is not a real dispatch system.
  - To ship an update, bump the CACHE constant in sw.js (e.g. v5 -> v6) so clients
    discard the old shell.


================================================================================
9. CUSTOMISATION TIPS
================================================================================

  - Database credentials: edit includes/config.php or set SYNCPULSE_DB_* vars.
  - Branding/colors/layout: edit assets/css/style.css.
  - Health guide content and translations: edit getArticles() in includes/data.php.
  - Add a worker view: add a case to the $views map in worker/index.php and create
    the matching file under worker/pages/.
  - Add an admin view: extend the $views whitelist and nav in admin/index.php and
    admin/components/sidebar.php.
  - Change session/cookie policy: adjust includes/auth.php before session_start().
  - Seed data: edit the arrays in database/setup.php (runs only when a table is
    empty).


================================================================================
10. TROUBLESHOOTING
================================================================================

  "Setup failed" / cannot connect
    - Confirm MySQL is running and the credentials in includes/config.php (or the
      SYNCPULSE_DB_* environment variables) are correct.
    - Ensure the PHP pdo_mysql extension is enabled.

  Database created but pages show no data
    - Run "php database/setup.php" again; it seeds only empty tables. Demo data
      is not created if tables already contain rows.

  "Session expired. Please reload the page and try again." (HTTP 419)
    - The CSRF token did not match. Reload the page and resubmit; this is normal
      after a session expires or cookies are cleared.

  Worker cannot sign in
    - The account may be inactive (super admin must reactivate it), or the Worker
      ID/password is wrong. Worker IDs are case-insensitive (stored uppercase).

  Icons look missing
    - Lucide loads from unpkg.com. Without internet the layout still works but
      icons may not render. Google Fonts likewise falls back to system fonts.

  Offline mode does not work
    - Use an HTTP server and load the site online once. Clear old service workers
      / bump the CACHE version after updates.

  Reset everything (DESTRUCTIVE - deletes all data)
    - Drop the "syncpulse" database manually, then run
      "php database/setup.php" again to rebuild and reseed it.


================================================================================
11. LIMITATIONS / DEMO DISCLAIMERS
================================================================================

  - This is a demonstration app. All people, villages, visits, and alerts are
    fictional.
  - Alerts, help requests, and visits are stored in MySQL only. They do not send
    SMS/email, contact a doctor, dispatch an ambulance, or reach emergency
    services. For real emergencies, call 112 (India) or local emergency services.
  - Medical guide text is general education, not diagnosis or a substitute for
    professional care, and needs local clinical review before real use.
  - The language selector affects guide preview text only; the rest of the
    interface is English.
  - There is no pagination or audit log; lists show all matching records.

================================================================================
END OF FILE
================================================================================
