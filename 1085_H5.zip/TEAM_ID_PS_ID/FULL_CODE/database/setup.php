<?php
require_once __DIR__ . '/../includes/db.php';

$isCli = PHP_SAPI === 'cli';

function setup_line(string $message, bool $isCli): void
{
    if ($isCli) {
        echo $message . PHP_EOL;
    } else {
        echo htmlspecialchars($message) . "<br>\n";
    }
}

try {
    $config = db_config();
    $server = db_server();
    $server->exec(sprintf(
        'CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci',
        str_replace('`', '', $config['name'])
    ));
    setup_line('Database "' . $config['name'] . '" is ready.', $isCli);

    $schema = file_get_contents(__DIR__ . '/schema.sql');
    db()->exec($schema);
    setup_line('Tables created.', $isCli);

    $adminCount = (int) db()->query('SELECT COUNT(*) FROM admins')->fetchColumn();
    $workerCount = (int) db()->query('SELECT COUNT(*) FROM workers')->fetchColumn();
    $patientCount = (int) db()->query('SELECT COUNT(*) FROM patients')->fetchColumn();

    if ($adminCount === 0) {
        $statement = db()->prepare('INSERT INTO admins (name, email, password_hash) VALUES (?, ?, ?)');
        $statement->execute(['SyncPulse Admin', 'admin@syncpulse.local', password_hash('Admin@123', PASSWORD_DEFAULT)]);
        setup_line('Created default super admin: admin@syncpulse.local / Admin@123', $isCli);
    }

    if ($workerCount === 0) {
        $statement = db()->prepare(
            'INSERT INTO workers (worker_code, name, email, phone, village, password_hash, status, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $adminId = (int) db()->query('SELECT id FROM admins ORDER BY id LIMIT 1')->fetchColumn();
        $workerPassword = password_hash('Worker@123', PASSWORD_DEFAULT);
        $statement->execute(['DEMO-ASHA-001', 'Sunita Kumari', 'sunita@syncpulse.local', '9876543210', 'Rampur', $workerPassword, 'active', $adminId]);
        $statement->execute(['DEMO-ASHA-002', 'Meena Rao', 'meena@syncpulse.local', '9876543211', 'Chandpur', $workerPassword, 'active', $adminId]);
        setup_line('Created demo workers: DEMO-ASHA-001 and DEMO-ASHA-002 / Worker@123', $isCli);
    }

    if ($patientCount === 0) {
        $workers = db()->query('SELECT id, village FROM workers WHERE status = "active"')->fetchAll();
        $workerByVillage = [];
        $firstWorkerId = null;
        foreach ($workers as $worker) {
            if ($firstWorkerId === null) {
                $firstWorkerId = (int) $worker['id'];
            }
            $workerByVillage[strtolower($worker['village'])] ??= (int) $worker['id'];
        }

        $patients = [
            ['Lakshmi Devi', 'lakshmi.devi@example.com', '9000000001', 28, 'Female', 'Rampur', 'Maternal care', 'Pregnancy, 24 weeks. Routine antenatal check-up due. No known allergies.', '4 members · Husband, mother-in-law, 1 child'],
            ['Ramesh Kumar', 'ramesh.kumar@example.com', '9000000002', 62, 'Male', 'Rampur', 'Chronic care', 'Hypertension. Monthly blood pressure monitoring and prescribed medication review.', '3 members · Wife and son'],
            ['Anjali Yadav', 'anjali.yadav@example.com', '9000000003', 3, 'Female', 'Chandpur', 'Child health', 'Routine immunisation and growth monitoring. Guardian: Sunita Yadav.', '5 members · Parents, grandmother, sibling'],
            ['Sunita Patel', 'sunita.patel@example.com', '9000000004', 35, 'Female', 'Rampur', 'General care', 'Routine wellness visit. Previous visit: nutrition and hygiene counselling.', '4 members · Husband and 2 children'],
            ['Mohan Lal', 'mohan.lal@example.com', '9000000005', 68, 'Male', 'Chandpur', 'Chronic care', 'Type 2 diabetes. Regular clinician follow-up advised.', '2 members · Wife'],
            ['Priya Sharma', 'priya.sharma@example.com', '9000000006', 24, 'Female', 'Rampur', 'Maternal care', 'Postnatal review, 6 weeks. Infant feeding support requested.', '3 members · Husband and infant'],
            ['Aarav Singh', 'aarav.singh@example.com', '9000000007', 5, 'Male', 'Chandpur', 'Child health', 'Growth and development review. No known allergies.', '4 members · Parents and sibling'],
            ['Kamala Bai', 'kamala.bai@example.com', '9000000008', 57, 'Female', 'Rampur', 'General care', 'Routine health screening. Reports occasional knee discomfort.', '3 members · Husband and daughter'],
        ];

        $insertPatient = db()->prepare(
            'INSERT INTO patients (name, email, phone, password_hash, age, gender, village, category, history, family, assigned_worker_id, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active")'
        );
        $patientPassword = password_hash('Patient@123', PASSWORD_DEFAULT);
        $patientIds = [];
        foreach ($patients as $patient) {
            $workerId = $workerByVillage[strtolower($patient[5])] ?? $firstWorkerId;
            $insertPatient->execute([
                $patient[0], $patient[1], $patient[2], $patientPassword, $patient[3],
                $patient[4], $patient[5], $patient[6], $patient[7], $patient[8], $workerId,
            ]);
            $patientIds[$patient[1]] = (int) db()->lastInsertId();
        }

        $workerIds = [];
        foreach (db()->query('SELECT id, village FROM workers')->fetchAll() as $worker) {
            $workerIds[strtolower($worker['village'])] = (int) $worker['id'];
        }

        $today = new DateTime('today');
        $day = function (int $offset) use ($today): string {
            $date = clone $today;
            $date->modify(($offset >= 0 ? '+' : '') . $offset . ' days');
            return $date->format('Y-m-d');
        };

        $visits = [
            [$patientIds['lakshmi.devi@example.com'], $day(0), '09:30:00', 'Antenatal check-up', 'Upcoming'],
            [$patientIds['ramesh.kumar@example.com'], $day(0), '10:30:00', 'Blood pressure follow-up', 'Upcoming'],
            [$patientIds['anjali.yadav@example.com'], $day(0), '11:15:00', 'Child health & immunisation', 'Upcoming'],
            [$patientIds['sunita.patel@example.com'], $day(0), '14:00:00', 'Monthly health visit', 'Upcoming'],
            [$patientIds['mohan.lal@example.com'], $day(-2), '10:00:00', 'Diabetes follow-up', 'Upcoming'],
            [$patientIds['priya.sharma@example.com'], $day(2), '09:00:00', 'Postnatal check-up', 'Upcoming'],
            [$patientIds['kamala.bai@example.com'], $day(-1), '10:00:00', 'Monthly health visit', 'Completed'],
            [$patientIds['aarav.singh@example.com'], $day(-3), '11:00:00', 'Growth monitoring', 'Completed'],
            [$patientIds['sunita.patel@example.com'], $day(-6), '14:30:00', 'Monthly health visit', 'Completed'],
        ];
        $insertVisit = db()->prepare(
            'INSERT INTO visits (patient_id, worker_id, visit_date, visit_time, type, status)
             SELECT ?, assigned_worker_id, ?, ?, ?, ? FROM patients WHERE id = ?'
        );
        foreach ($visits as $visit) {
            $insertVisit->execute([$visit[0], $visit[1], $visit[2], $visit[3], $visit[4], $visit[0]]);
        }

        $alerts = [
            [$patientIds['mohan.lal@example.com'], 'Dizziness and weakness reported by family', 'High', 0, $day(-1)],
            [$patientIds['kamala.bai@example.com'], 'Help requested with a follow-up appointment', 'Help request', 0, $day(0)],
            [$patientIds['ramesh.kumar@example.com'], 'Family asked for a blood pressure recheck', 'Medium', 1, $day(-2)],
        ];
        $insertAlert = db()->prepare(
            'INSERT INTO alerts (patient_id, worker_id, condition_text, urgency, resolved, resolved_at, created_at)
             SELECT ?, assigned_worker_id, ?, ?, ?, ?, ? FROM patients WHERE id = ?'
        );
        foreach ($alerts as $alert) {
            $insertAlert->execute([
                $alert[0], $alert[1], $alert[2], $alert[3],
                $alert[3] ? date('Y-m-d H:i:s') : null,
                $alert[4] . ' 09:00:00',
                $alert[0],
            ]);
        }

        setup_line('Seeded demo patients, visits, and alerts. Patient password: Patient@123', $isCli);
    }

    setup_line('Setup complete.', $isCli);
} catch (Throwable $error) {
    http_response_code(500);
    error_log('SyncPulse setup failed: ' . $error->getMessage());
    setup_line(
        $isCli ? 'Setup failed: ' . $error->getMessage() : 'Setup failed. Check the server log for details.',
        $isCli
    );
    if (!$isCli) {
        echo '<p>Check the database settings in <code>FULL_CODE/.env</code> or your environment variables.</p>';
    }
    exit(1);
}
