CREATE TABLE IF NOT EXISTS admins (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS workers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    worker_code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(30) DEFAULT NULL,
    village VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_by INT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_workers_admin FOREIGN KEY (created_by) REFERENCES admins (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patients (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(30) NOT NULL,
    password_hash VARCHAR(255) DEFAULT NULL,
    age TINYINT UNSIGNED NOT NULL,
    gender ENUM('Female', 'Male', 'Other') NOT NULL,
    village VARCHAR(100) NOT NULL,
    category ENUM('General care', 'Maternal care', 'Child health', 'Chronic care') NOT NULL DEFAULT 'General care',
    history TEXT DEFAULT NULL,
    family VARCHAR(255) DEFAULT NULL,
    assigned_worker_id INT UNSIGNED DEFAULT NULL,
    created_by_worker_id INT UNSIGNED DEFAULT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_patients_worker FOREIGN KEY (assigned_worker_id) REFERENCES workers (id) ON DELETE SET NULL,
    CONSTRAINT fk_patients_creator FOREIGN KEY (created_by_worker_id) REFERENCES workers (id) ON DELETE SET NULL,
    INDEX idx_patients_worker (assigned_worker_id),
    INDEX idx_patients_village (village)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS visits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id INT UNSIGNED NOT NULL,
    worker_id INT UNSIGNED DEFAULT NULL,
    visit_date DATE NOT NULL,
    visit_time TIME NOT NULL,
    type VARCHAR(120) NOT NULL,
    status ENUM('Upcoming', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Upcoming',
    notes TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_visits_patient FOREIGN KEY (patient_id) REFERENCES patients (id) ON DELETE CASCADE,
    CONSTRAINT fk_visits_worker FOREIGN KEY (worker_id) REFERENCES workers (id) ON DELETE SET NULL,
    INDEX idx_visits_date (visit_date),
    INDEX idx_visits_worker (worker_id),
    INDEX idx_visits_patient (patient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS alerts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id INT UNSIGNED NOT NULL,
    worker_id INT UNSIGNED DEFAULT NULL,
    condition_text VARCHAR(255) NOT NULL,
    urgency ENUM('High', 'Medium', 'Help request') NOT NULL DEFAULT 'Help request',
    resolved TINYINT(1) NOT NULL DEFAULT 0,
    resolved_by INT UNSIGNED DEFAULT NULL,
    resolved_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_alerts_patient FOREIGN KEY (patient_id) REFERENCES patients (id) ON DELETE CASCADE,
    CONSTRAINT fk_alerts_worker FOREIGN KEY (worker_id) REFERENCES workers (id) ON DELETE SET NULL,
    CONSTRAINT fk_alerts_resolver FOREIGN KEY (resolved_by) REFERENCES workers (id) ON DELETE SET NULL,
    INDEX idx_alerts_worker (worker_id),
    INDEX idx_alerts_resolved (resolved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
