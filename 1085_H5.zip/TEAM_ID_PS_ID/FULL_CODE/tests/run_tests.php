<?php

require_once __DIR__ . '/../includes/data.php';

$failures = 0;
$checks = 0;

function check(string $label, $actual, $expected): void
{
    global $failures, $checks;
    $checks++;
    if ($actual === $expected) {
        echo "PASS  {$label}\n";
        return;
    }
    $failures++;
    echo "FAIL  {$label}\n";
    echo '      expected: ' . var_export($expected, true) . "\n";
    echo '      actual:   ' . var_export($actual, true) . "\n";
}

check('initials two-part name', initials('Lakshmi Devi'), 'LD');
check('initials single name', initials('Aarav'), 'AA');
check('initials three-part name', initials('A B C'), 'AB');
check('initials trims whitespace', initials('  Sunita  Kumari  '), 'SK');
check('initials empty input', initials(''), '');

check('dateLabel normal date', dateLabel('2026-10-29'), '29 Oct');
check('dateLabel leap day', dateLabel('2024-02-29'), '29 Feb');
check('dateLabel month boundary', dateLabel('2026-01-01'), '01 Jan');

$articles = getArticles();
check('article count', count($articles), 4);
$requiredKeys = ['id', 'title', 'category', 'time', 'body', 'hi', 'te'];
check('first article has all fields', array_keys($articles[0]), $requiredKeys);
check('article ids are unique', count(array_unique(array_column($articles, 'id'))), 4);
check('every article has a title', count(array_filter($articles, fn ($a) => trim($a['title']) !== '')), 4);

$config = db_config();
check('db_config returns host', is_string($config['host']) && $config['host'] !== '', true);
check('db_config returns name', is_string($config['name']) && $config['name'] !== '', true);
check('db_config returns integer-like port', ctype_digit((string) $config['port']), true);

$tempEnv = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'syncpulse_env_test_' . bin2hex(random_bytes(4)) . '.env';
file_put_contents($tempEnv, "SYNCPULSE_TEST_ALPHA=alpha-value\nSYNCPULSE_TEST_QUOTED=\"quoted value\"\n# comment\nSYNCPULSE_TEST_ALPHA=ignored-second-value\n");
putenv('SYNCPULSE_TEST_ALPHA');
putenv('SYNCPULSE_TEST_QUOTED');
syncpulse_load_env_file($tempEnv);
check('env loader reads plain value', getenv('SYNCPULSE_TEST_ALPHA'), 'alpha-value');
check('env loader strips quotes', getenv('SYNCPULSE_TEST_QUOTED'), 'quoted value');
putenv('SYNCPULSE_TEST_ALPHA');
putenv('SYNCPULSE_TEST_QUOTED');
unlink($tempEnv);

$source = file_get_contents(__DIR__ . '/../includes/data.php');
check('patient queries do not select password hashes', str_contains($source, 'password_hash'), false);

echo "\n{$checks} checks, {$failures} failure(s)\n";
exit($failures === 0 ? 0 : 1);
