<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/data.php';

if (current_patient_id()) {
    redirect_to('index.php');
}

$error = '';
$form = [
    'name' => '',
    'email' => '',
    'phone' => '',
    'age' => '',
    'gender' => 'Female',
    'village' => '',
    'category' => 'General care',
    'history' => '',
    'family' => '',
];
$genders = ['Female', 'Male', 'Other'];
$categories = ['General care', 'Maternal care', 'Child health', 'Chronic care'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach ($form as $key => $value) {
        $form[$key] = trim($_POST[$key] ?? '');
    }
    $form['email'] = strtolower($form['email']);
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';

    if ($form['name'] === '') {
        $error = 'Enter your full name.';
    } elseif (!filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif ($form['phone'] === '') {
        $error = 'Enter a phone number.';
    } elseif ((int) $form['age'] < 1 || (int) $form['age'] > 120) {
        $error = 'Enter a valid age.';
    } elseif (!in_array($form['gender'], $genders, true)) {
        $error = 'Choose a gender.';
    } elseif ($form['village'] === '') {
        $error = 'Enter your village.';
    } elseif (!in_array($form['category'], $categories, true)) {
        $error = 'Choose a care category.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    }

    if ($error === '') {
        $workerId = null;
        $workerStatement = db()->prepare(
            'SELECT id FROM workers WHERE status = "active" AND village = ? ORDER BY id LIMIT 1'
        );
        $workerStatement->execute([$form['village']]);
        $workerId = $workerStatement->fetchColumn();
        if (!$workerId) {
            $workerId = db()->query('SELECT id FROM workers WHERE status = "active" ORDER BY id LIMIT 1')->fetchColumn() ?: null;
        }

        try {
            $statement = db()->prepare(
                'INSERT INTO patients
                    (name, email, phone, password_hash, age, gender, village, category, history, family, assigned_worker_id, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active")'
            );
            $statement->execute([
                $form['name'],
                $form['email'],
                $form['phone'],
                password_hash($password, PASSWORD_DEFAULT),
                (int) $form['age'],
                $form['gender'],
                $form['village'],
                $form['category'],
                $form['history'] !== '' ? $form['history'] : null,
                $form['family'] !== '' ? $form['family'] : null,
                $workerId,
            ]);

            login_user([
                'id' => db()->lastInsertId(),
                'role' => 'patient',
                'name' => $form['name'],
                'email' => $form['email'],
                'village' => $form['village'],
            ]);
            flash('success', 'Your patient account is ready. Welcome to SyncPulse.');
            redirect_to('index.php');
        } catch (PDOException $exception) {
            if ((int) $exception->getCode() === 23000) {
                $error = 'An account already exists with that email address.';
            } else {
                $error = 'Could not create your account. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration · SyncPulse</title>
    <link rel="manifest" href="../assets/manifest.webmanifest">
    <link rel="icon" href="../assets/icon.svg" type="image/svg+xml">
    <link rel="icon" href="../assets/favicon.ico" sizes="any">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="auth-body">
    <main class="auth-page">
        <div class="auth-card auth-card-wide">
            <a class="auth-brand" href="../index.php">
                <span class="brand-mark"><i data-lucide="heart"></i></span>
                <span>Sync<span class="brand-pulse">Pulse</span><small>CONNECTED COMMUNITY CARE</small></span>
            </a>
            <h1>Create your patient account</h1>
            <p>Register directly. An ASHA worker in your village will be assigned to support your care.</p>

            <?php if ($error !== ''): ?>
                <div class="auth-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form class="app-form" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-grid">
                    <label>Full name<input type="text" name="name" value="<?php echo htmlspecialchars($form['name']); ?>" autocomplete="name" required></label>
                    <label>Age<input type="number" name="age" value="<?php echo htmlspecialchars($form['age']); ?>" min="1" max="120" required></label>
                </div>
                <div class="form-grid">
                    <label>Gender
                        <select name="gender">
                            <?php foreach ($genders as $gender): ?>
                                <option <?php echo $form['gender'] === $gender ? 'selected' : ''; ?>><?php echo $gender; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label>Village<input type="text" name="village" value="<?php echo htmlspecialchars($form['village']); ?>" required></label>
                </div>
                <div class="form-grid">
                    <label>Email address<input type="email" name="email" value="<?php echo htmlspecialchars($form['email']); ?>" autocomplete="username" required></label>
                    <label>Phone<input type="tel" name="phone" value="<?php echo htmlspecialchars($form['phone']); ?>" autocomplete="tel" required></label>
                </div>
                <label>Care category
                    <select name="category">
                        <?php foreach ($categories as $category): ?>
                            <option <?php echo $form['category'] === $category ? 'selected' : ''; ?>><?php echo htmlspecialchars($category); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Medical history (optional)<textarea name="history"><?php echo htmlspecialchars($form['history']); ?></textarea></label>
                <label>Family details (optional)<input type="text" name="family" value="<?php echo htmlspecialchars($form['family']); ?>" placeholder="e.g. 4 members · Husband and 2 children"></label>
                <div class="form-grid">
                    <label>Password<input type="password" name="password" minlength="8" autocomplete="new-password" required></label>
                    <label>Confirm password<input type="password" name="password_confirm" minlength="8" autocomplete="new-password" required></label>
                </div>
                <div class="form-actions">
                    <button class="primary-button" type="submit">Create account</button>
                </div>
            </form>

            <a class="auth-back" href="login.php"><i data-lucide="arrow-left"></i> Already registered? Sign in</a><br>
            <a class="auth-back" href="../index.php"><i data-lucide="arrow-left"></i> Back to home</a>
        </div>
    </main>

    <script src="https://unpkg.com/lucide@1.64.0/dist/umd/lucide.js"></script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
