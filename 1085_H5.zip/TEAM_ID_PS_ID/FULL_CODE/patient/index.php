<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/data.php';
require_patient();

$patientId = current_patient_id();
$genders = ['Female', 'Male', 'Other'];
$categories = ['General care', 'Maternal care', 'Child health', 'Chronic care'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $age = (int) ($_POST['age'] ?? 0);
        $gender = $_POST['gender'] ?? '';
        $village = trim($_POST['village'] ?? '');
        $category = $_POST['category'] ?? '';
        $history = trim($_POST['history'] ?? '');
        $family = trim($_POST['family'] ?? '');

        if ($name === '' || $phone === '' || $village === '' || $age < 1 || $age > 120
            || !in_array($gender, $genders, true) || !in_array($category, $categories, true)) {
            flash('error', 'Please complete all required profile fields.');
            redirect_to('index.php');
        }

        $statement = db()->prepare(
            'UPDATE patients
             SET name = ?, phone = ?, age = ?, gender = ?, village = ?, category = ?, history = ?, family = ?
             WHERE id = ?'
        );
        $statement->execute([
            $name,
            $phone,
            $age,
            $gender,
            $village,
            $category,
            $history !== '' ? $history : null,
            $family !== '' ? $family : null,
            $patientId,
        ]);
        $_SESSION['user']['name'] = $name;
        $_SESSION['user']['village'] = $village;
        flash('success', 'Your health profile was updated.');
        redirect_to('index.php');
    }

    if ($action === 'request_help') {
        $condition = trim($_POST['condition'] ?? '');
        $urgency = $_POST['urgency'] ?? 'Help request';
        if ($condition === '') {
            flash('error', 'Tell your ASHA worker what you need help with.');
            redirect_to('index.php');
        }
        if (!in_array($urgency, ['High', 'Medium', 'Help request'], true)) {
            $urgency = 'Help request';
        }

        $workerStatement = db()->prepare('SELECT assigned_worker_id FROM patients WHERE id = ?');
        $workerStatement->execute([$patientId]);
        $workerId = $workerStatement->fetchColumn();
        if (!$workerId) {
            $workerId = db()->query('SELECT id FROM workers WHERE status = "active" ORDER BY id LIMIT 1')->fetchColumn() ?: null;
        }

        $statement = db()->prepare(
            'INSERT INTO alerts (patient_id, worker_id, condition_text, urgency) VALUES (?, ?, ?, ?)'
        );
        $statement->execute([$patientId, $workerId, $condition, $urgency]);
        flash('success', 'Your help request was sent to your ASHA worker.');
        redirect_to('index.php');
    }

    if ($action === 'book_visit') {
        $date = $_POST['visit_date'] ?? '';
        $time = $_POST['visit_time'] ?? '';
        $type = trim($_POST['type'] ?? '');
        if ($date === '' || $time === '' || $type === '') {
            flash('error', 'Choose a date, time, and visit type.');
            redirect_to('index.php');
        }

        $workerStatement = db()->prepare('SELECT assigned_worker_id FROM patients WHERE id = ?');
        $workerStatement->execute([$patientId]);
        $workerId = $workerStatement->fetchColumn();
        if (!$workerId) {
            $workerId = db()->query('SELECT id FROM workers WHERE status = "active" ORDER BY id LIMIT 1')->fetchColumn() ?: null;
        }

        $statement = db()->prepare(
            'INSERT INTO visits (patient_id, worker_id, visit_date, visit_time, type, status)
             VALUES (?, ?, ?, ?, ?, "Upcoming")'
        );
        $statement->execute([$patientId, $workerId, $date, $time, $type]);
        flash('success', 'Your visit request was sent to your ASHA worker.');
        redirect_to('index.php');
    }

    if ($action === 'cancel_visit') {
        $visitId = (int) ($_POST['visit_id'] ?? 0);
        $statement = db()->prepare(
            'UPDATE visits SET status = "Cancelled"
             WHERE id = ? AND patient_id = ? AND status = "Upcoming"'
        );
        $statement->execute([$visitId, $patientId]);
        flash($statement->rowCount() ? 'success' : 'error', $statement->rowCount() ? 'Visit cancelled.' : 'That visit could not be cancelled.');
        redirect_to('index.php');
    }

    redirect_to('index.php');
}

$p = get_patient_by_id($patientId);
if (!$p) {
    logout_user();
    redirect_to('login.php');
}
$data = getSeedData('all');
$myVisits = array_values(array_filter($data['visits'], function ($visit) use ($patientId) {
    return (int) $visit['patientId'] === $patientId;
}));
$myAlerts = array_values(array_filter($data['alerts'], function ($alert) use ($patientId) {
    return (int) $alert['patientId'] === $patientId;
}));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($p['name']); ?> · SyncPulse Patient Portal</title>
    <meta name="description" content="SyncPulse patient portal.">
    <link rel="manifest" href="../assets/manifest.webmanifest">
    <link rel="icon" href="../assets/icon.svg" type="image/svg+xml">
    <link rel="icon" href="../assets/favicon.ico" sizes="any">
    <link rel="apple-touch-icon" href="../assets/icon-192.png">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="patient-shell">
        <?php include __DIR__ . '/components/header.php'; ?>
        <main>
            <?php include __DIR__ . '/components/offline-notice.php'; ?>
            <?php render_flashes(); ?>
            <?php include __DIR__ . '/pages/portal.php'; ?>
        </main>
    </div>

    <?php include __DIR__ . '/components/modals.php'; ?>

    <script src="https://unpkg.com/lucide@1.64.0/dist/umd/lucide.js"></script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
