<?php
$patientName = $p['name'] ?? 'Patient';
$patientInitials = function_exists('initials') ? initials($patientName) : 'PT';
?>
<header class="topbar patient-topbar">
    <a class="brand patient-brand" href="index.php">
        <span class="brand-mark"><i data-lucide="activity"></i></span>
        <span>
            Sync<span class="brand-pulse">Pulse</span>
            <small>PATIENT PORTAL</small>
        </span>
    </a>
    <div class="top-actions">
        <span class="connection" id="connectionStatus">
            <i data-lucide="wifi"></i>
            <span>Online</span>
        </span>
        <span class="top-divider"></span>
        <span class="patient-chip">
            <span class="avatar"><?php echo htmlspecialchars($patientInitials); ?></span>
            <span><?php echo htmlspecialchars($patientName); ?></span>
        </span>
        <a class="secondary-button signout-button" href="logout.php">
            <i data-lucide="log-out"></i>
            <span>Sign out</span>
        </a>
    </div>
</header>
