<?php
$patientName = $p['name'] ?? 'Patient';
$genders = ['Female', 'Male', 'Other'];
$categories = ['General care', 'Maternal care', 'Child health', 'Chronic care'];
?>
<div id="modal-overlay" class="modal-overlay" onclick="closeModal()"></div>

<div id="modal-emergency" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Request help</h2>
        <p>Send a request to your ASHA worker. For a real emergency, call 112.</p>
        <form class="app-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="request_help">
            <div class="response-card">
                <strong>Patient</strong>
                <p><?php echo htmlspecialchars($patientName); ?></p>
            </div>
            <label>What do you need help with?<textarea name="condition" required></textarea></label>
            <label>Urgency
                <select name="urgency">
                    <option>High</option>
                    <option>Medium</option>
                    <option>Help request</option>
                </select>
            </label>
            <div class="form-actions">
                <button class="danger-button" type="submit">Send request</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="modal-schedule" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Book a visit</h2>
        <p>Choose a preferred time for a home visit.</p>
        <form class="app-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="book_visit">
            <div class="response-card">
                <strong>Patient</strong>
                <p><?php echo htmlspecialchars($patientName); ?></p>
            </div>
            <div class="form-grid">
                <label>Date<input type="date" name="visit_date" value="<?php echo date('Y-m-d'); ?>" required></label>
                <label>Time<input type="time" name="visit_time" value="09:00" required></label>
            </div>
            <label>Visit type
                <select name="type">
                    <option>Monthly health visit</option>
                    <option>Antenatal check-up</option>
                    <option>Child health &amp; immunisation</option>
                    <option>Blood pressure follow-up</option>
                    <option>Diabetes follow-up</option>
                    <option>Postnatal check-up</option>
                </select>
            </label>
            <div class="form-actions">
                <button class="primary-button" type="submit">Book visit</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="modal-profile" class="modal">
    <div class="modal-content sync-dialog">
        <button class="modal-close" onclick="closeModal()"><i data-lucide="x"></i></button>
        <h2>Edit health profile</h2>
        <p>Keep your care information up to date for your ASHA worker.</p>
        <form class="app-form" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="update_profile">
            <div class="form-grid">
                <label>Full name<input type="text" name="name" value="<?php echo htmlspecialchars($p['name']); ?>" required></label>
                <label>Phone<input type="tel" name="phone" value="<?php echo htmlspecialchars($p['phone']); ?>" required></label>
            </div>
            <div class="form-grid">
                <label>Age<input type="number" name="age" value="<?php echo (int) $p['age']; ?>" min="1" max="120" required></label>
                <label>Gender
                    <select name="gender">
                        <?php foreach ($genders as $gender): ?>
                            <option <?php echo $p['gender'] === $gender ? 'selected' : ''; ?>><?php echo $gender; ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <div class="form-grid">
                <label>Village<input type="text" name="village" value="<?php echo htmlspecialchars($p['village']); ?>" required></label>
                <label>Care category
                    <select name="category">
                        <?php foreach ($categories as $category): ?>
                            <option <?php echo $p['category'] === $category ? 'selected' : ''; ?>><?php echo htmlspecialchars($category); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <label>Medical history<textarea name="history"><?php echo htmlspecialchars($p['history'] ?? ''); ?></textarea></label>
            <label>Family details<input type="text" name="family" value="<?php echo htmlspecialchars($p['family'] ?? ''); ?>"></label>
            <div class="form-actions">
                <button class="primary-button" type="submit">Save profile</button>
                <button class="secondary-button" type="button" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>
