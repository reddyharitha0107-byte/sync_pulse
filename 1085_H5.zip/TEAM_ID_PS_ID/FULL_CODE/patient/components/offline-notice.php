<div class="offline-notice" role="status">
    <strong>Offline access ready</strong>
    <p>Previously loaded health information stays readable without internet. Help requests and visit bookings require a connection. No emergency service is contacted.</p>
</div>
