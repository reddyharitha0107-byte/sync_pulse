<?php
if (!isset($p)) {
    http_response_code(403);
    exit('Patient portal is not available.');
}
$myVisits = $myVisits ?? [];
$myAlerts = $myAlerts ?? [];
$workerName = $p['worker_name'] ?? 'your ASHA worker';
?>
<div class="page-heading">
    <div>
        <div class="eyebrow">YOUR CARE, YOUR COMMUNITY</div>
        <h1>Hello, <?php echo htmlspecialchars(explode(' ', $p['name'])[0]); ?></h1>
        <p>Stay connected with <?php echo htmlspecialchars($workerName); ?>.</p>
    </div>
</div>

<div class="patient-banner">
    <div class="avatar"><?php echo initials($p['name']); ?></div>
    <div>
        <h2><?php echo htmlspecialchars($p['name']); ?></h2>
        <p><?php echo (int) $p['age']; ?> years · <?php echo htmlspecialchars($p['gender']); ?> · <?php echo htmlspecialchars($p['village']); ?> · <?php echo htmlspecialchars($p['category']); ?></p>
        <span>
            <i data-lucide="phone"></i> <?php echo htmlspecialchars($p['phone']); ?>
        </span>
        <span>
            <i data-lucide="stethoscope"></i> <?php echo htmlspecialchars($workerName); ?>
        </span>
    </div>
</div>

<div class="portal-actions">
    <button class="primary-button" onclick="openModal('emergency')">
        <i data-lucide="siren"></i>
        Request help
    </button>
    <button class="secondary-button" onclick="openModal('schedule')">
        <i data-lucide="calendar-days"></i>
        Book visit
    </button>
    <button class="secondary-button" onclick="openModal('profile')">
        <i data-lucide="user-round-pen"></i>
        Edit profile
    </button>
</div>

<section class="panel">
    <div class="panel-header">
        <div>
            <h2>My health profile</h2>
            <p>Information shared with your ASHA worker</p>
        </div>
    </div>
    <div style="padding: 0 22px 22px;">
        <h3 style="font-weight: 600; font-size: 13px; margin: 20px 0 10px;">Medical history</h3>
        <p style="font-size: 12px; line-height: 1.9; color: #849979;"><?php echo nl2br(htmlspecialchars($p['history'] ?: 'No medical history recorded yet.')); ?></p>
        <h3 style="font-weight: 600; font-size: 13px; margin: 20px 0 10px;">Family</h3>
        <p style="font-size: 12px; line-height: 1.9; color: #849979;"><?php echo htmlspecialchars($p['family'] ?: 'No family details recorded yet.'); ?></p>
    </div>
</section>

<section class="panel patient-visits">
    <div class="panel-header">
        <div>
            <h2>My visits <span class="count"><?php echo count($myVisits); ?></span></h2>
            <p>Upcoming and recent care</p>
        </div>
    </div>
    <?php if (empty($myVisits)): ?>
        <p class="empty-small">No visits scheduled yet.</p>
    <?php else: ?>
        <div class="visit-list">
            <?php foreach ($myVisits as $visit): ?>
                <div class="visit-row">
                    <div class="avatar tone-1">
                        <i data-lucide="calendar-days"></i>
                    </div>
                    <div class="visit-info">
                        <span class="patient-name"><?php echo htmlspecialchars($visit['type']); ?></span>
                        <small>
                            <i data-lucide="clock-3"></i>
                            <?php echo dateLabel($visit['date']); ?> · <?php echo htmlspecialchars($visit['time']); ?>
                        </small>
                    </div>
                    <div class="visit-end">
                        <span class="badge <?php echo ($visit['status'] === 'Completed') ? 'green' : (($visit['status'] === 'Overdue' || $visit['status'] === 'Cancelled') ? 'red' : 'amber'); ?>">
                            <?php echo htmlspecialchars($visit['status']); ?>
                        </span>
                        <?php if ($visit['status'] !== 'Completed' && $visit['status'] !== 'Cancelled'): ?>
                        <form method="post" class="inline-form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="cancel_visit">
                            <input type="hidden" name="visit_id" value="<?php echo (int) $visit['id']; ?>">
                            <button class="status-action danger" type="submit" title="Cancel visit"><i data-lucide="x"></i></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<section class="panel patient-visits">
    <div class="panel-header">
        <div>
            <h2>My help requests <span class="count"><?php echo count($myAlerts); ?></span></h2>
            <p>Requests sent to your ASHA worker</p>
        </div>
    </div>
    <?php if (empty($myAlerts)): ?>
        <p class="empty-small">No help requests yet.</p>
    <?php else: ?>
        <div class="visit-list">
            <?php foreach ($myAlerts as $alert): ?>
                <div class="visit-row">
                    <div class="avatar tone-2">
                        <i data-lucide="siren"></i>
                    </div>
                    <div class="visit-info">
                        <span class="patient-name"><?php echo htmlspecialchars($alert['condition']); ?></span>
                        <small>
                            <i data-lucide="clock-3"></i>
                            <?php echo dateLabel(substr($alert['created'], 0, 10)); ?> · <?php echo htmlspecialchars($alert['urgency']); ?>
                        </small>
                    </div>
                    <div class="visit-end">
                        <span class="badge <?php echo $alert['resolved'] ? 'green' : 'amber'; ?>">
                            <?php echo $alert['resolved'] ? 'Resolved' : 'Open'; ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>
