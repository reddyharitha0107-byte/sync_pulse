const CACHE = 'syncpulse-shell-v5'
const INDEX_URL = new URL('./index.php', self.location).href
const PRECACHE = [
  INDEX_URL,
  new URL('./assets/css/style.css', self.location).href,
  new URL('./assets/js/app.js', self.location).href,
  new URL('./assets/manifest.webmanifest', self.location).href,
  new URL('./assets/icon.svg', self.location).href,
  new URL('./assets/icon-192.png', self.location).href,
  new URL('./assets/icon-512.png', self.location).href,
  new URL('./assets/favicon.ico', self.location).href,
]
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)))
  self.skipWaiting()
})
self.addEventListener('activate', (e) =>
  e.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((k) => k.startsWith('syncpulse-shell-') && k !== CACHE).map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  ),
)
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url)
  if (
    e.request.method !== 'GET' ||
    u.origin !== self.location.origin ||
    u.pathname.startsWith('/api/') ||
    u.pathname.startsWith('/.netlify/') ||
    (e.request.mode !== 'navigate' && !/\.(js|css|woff2?|png|svg|webp|ico|webmanifest)$/.test(u.pathname))
  )
    return
  if (e.request.mode === 'navigate') {
    e.respondWith(
      fetch(e.request, { signal: AbortSignal.timeout(5000) })
        .then(async (r) => {
          if (!r.ok) throw new Error('Navigation unavailable')
          const cache = await caches.open(CACHE)
          await cache.put(e.request, r.clone())
          return r
        })
        .catch(async () =>
          (await caches.match(e.request)) ||
          (await caches.match(INDEX_URL)) ||
          new Response('Open SyncPulse online once to prepare offline access.', { status: 503, headers: { 'Content-Type': 'text/plain' } }),
        ),
    )
    return
  }
  e.respondWith(
    caches.match(e.request).then(
      (cached) =>
        cached ||
        fetch(e.request).then((r) => {
          if (r.ok) {
            const copy = r.clone()
            caches.open(CACHE).then((c) => c.put(e.request, copy))
          }
          return r
        }),
    ),
  )
})
// Cache the initial document's scripts too: first visits may load them before
// this worker controls the page. Report readiness only after every asset saves.
self.addEventListener('message', (e) => {
  if (e.data?.type !== 'CACHE_ASSETS' || !Array.isArray(e.data.urls)) return
  e.waitUntil((async () => {
    try {
      const urls = new Set([
        INDEX_URL,
        new URL('./assets/manifest.webmanifest', self.location).href,
        new URL('./assets/icon.svg', self.location).href,
      ])
      for (const value of e.data.urls) {
        if (typeof value !== 'string') continue
        const url = new URL(value, self.location.origin)
        if (url.origin !== self.location.origin ||
          url.pathname.startsWith('/api/') ||
          url.pathname.startsWith('/.netlify/')) continue
        // Only cache app resources, never arbitrary data endpoints.
        if (/\.(js|css|woff2?|png|svg|webp|ico)$/.test(url.pathname)) urls.add(url.href)
      }
      const cache = await caches.open(CACHE)
      await Promise.all(Array.from(urls, async (url) => {
        if (!(await cache.match(url))) await cache.add(url)
      }))
      e.ports[0]?.postMessage({ ready: true })
    } catch {
      e.ports[0]?.postMessage({ ready: false })
    }
  })())
})
