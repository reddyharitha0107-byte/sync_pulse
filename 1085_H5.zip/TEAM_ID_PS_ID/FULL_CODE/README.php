<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SyncPulse PHP · Setup</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 820px; margin: 40px auto; padding: 0 20px; line-height: 1.6; color: #243b3b; }
        code { background: #f1f6f4; padding: 2px 5px; border-radius: 4px; }
        a { color: #087e72; }
        table { border-collapse: collapse; width: 100%; margin: 12px 0; }
        th, td { border: 1px solid #dce8e4; padding: 8px 10px; text-align: left; font-size: 14px; }
        th { background: #f1f6f4; }
    </style>
</head>
<body>
    <h1>SyncPulse PHP</h1>
    <p>Community care portal backed by MySQL. Super admins register ASHA workers, workers manage their patients, and patients can self-register.</p>

    <h2>1. Database setup</h2>
    <p>Start MySQL in Laragon, then run:</p>
    <pre><code>php database/setup.php</code></pre>
    <p>
        This creates the <code>syncpulse</code> database, all tables, and demo data.
        The setup is idempotent: existing tables and records are kept. You can also
        open <a href="database/setup.php">database/setup.php</a> in the browser.
    </p>
    <p>
        Database credentials are read from environment variables. Copy
        <code>.env.example</code> to <code>.env</code> and edit it, or set
        <code>SYNCPULSE_DB_HOST</code>, <code>SYNCPULSE_DB_PORT</code>,
        <code>SYNCPULSE_DB_NAME</code>, <code>SYNCPULSE_DB_USER</code>, and
        <code>SYNCPULSE_DB_PASS</code> in your server environment. Laragon's default
        <code>root</code> user with an empty password is used only when no value is supplied.
    </p>

    <h2>2. Demo accounts</h2>
    <table>
        <tr><th>Role</th><th>Login</th><th>Password</th></tr>
        <tr><td>Super admin</td><td>admin@syncpulse.local</td><td>Admin@123</td></tr>
        <tr><td>ASHA worker</td><td>DEMO-ASHA-001</td><td>Worker@123</td></tr>
        <tr><td>ASHA worker</td><td>DEMO-ASHA-002</td><td>Worker@123</td></tr>
        <tr><td>Patient</td><td>lakshmi.devi@example.com</td><td>Patient@123</td></tr>
    </table>

    <h2>3. Open the app</h2>
    <ul>
        <li><a href="index.php">Landing page</a> - choose a portal</li>
        <li><a href="admin/login.php">Super admin login</a> - register and manage workers</li>
        <li><a href="worker/login.php">ASHA worker login</a> - patients, visits, and alerts</li>
        <li><a href="patient/login.php">Patient login</a> - health profile and requests</li>
        <li><a href="patient/register.php">Patient registration</a> - public self-registration</li>
    </ul>

    <h2>4. Features</h2>
    <ul>
        <li><strong>Super admin:</strong> register ASHA workers, activate/deactivate accounts, view every patient, visit, and alert.</li>
        <li><strong>ASHA worker:</strong> add patients, edit profiles, schedule visits, mark visits complete/cancelled, create alerts, and resolve them.</li>
        <li><strong>Patient:</strong> self-register, sign in, edit health profile, request help, book a visit, and cancel an upcoming visit.</li>
        <li><strong>Automatic assignment:</strong> a self-registering patient is assigned to an active worker in the same village when possible.</li>
        <li><strong>Security:</strong> passwords use <code>password_hash</code>, all writes use prepared statements, and forms are CSRF protected.</li>
    </ul>

    <h2>5. Project structure</h2>
    <pre>
index.php              Landing page
admin/                 Super admin login, dashboard, worker registration
worker/                ASHA worker login and workspace
patient/               Patient login, registration, and portal
includes/
  config.php           Database configuration
  db.php               PDO connection helpers
  auth.php             Sessions, roles, CSRF, flash messages
  data.php             Database queries used by the portals
database/
  schema.sql           MySQL table definitions
  setup.php            Creates the database, tables, and demo seed data
assets/                CSS, JavaScript, manifest, icons
sw.js                  Service worker
    </pre>

    <h2>Notes</h2>
    <ul>
        <li>Requires PHP 8.1 or newer and MySQL 5.7+/8.0+.</li>
        <li>All demo data is fictional. Replace the seeded accounts before any real deployment.</li>
        <li>Offline caching requires one online visit first. Service worker and manifest need an HTTP server.</li>
    </ul>
</body>
</html>
